import express, { Request, Response } from 'express';
import multer from 'multer';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Configure body limits for direct base64 audio/video
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// Configure multer for file uploads in memory
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 100 * 1024 * 1024, // 100 MB max
  },
});

function getGeminiClient(customApiKey?: string): GoogleGenAI {
  const apiKey = (customApiKey && customApiKey.trim()) || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('No Gemini API key provided. Please enter an API key or set GEMINI_API_KEY.');
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Fast check if server environment key exists & auto-connect
app.get('/api/config-status', async (_req: Request, res: Response) => {
  const hasEnvKey = Boolean(process.env.GEMINI_API_KEY);
  let isConnected = false;
  let latencyMs = 0;

  if (hasEnvKey) {
    try {
      const startTime = Date.now();
      const ai = getGeminiClient();
      // Fast metadata get (runs in ~150ms instead of 3000ms LLM generation)
      await ai.models.get({ model: 'gemini-2.5-flash' });
      latencyMs = Date.now() - startTime;
      isConnected = true;
    } catch (e: any) {
      console.warn('Fast server key test notice:', e?.message || e);
    }
  }

  res.json({
    hasEnvKey,
    autoConnected: isConnected,
    latencyMs,
    model: 'gemini-3.8-flash',
  });
});

// 2. Validate API Key connection - ULTRA FAST CHECK (<200ms)
app.post('/api/validate-key', async (req: Request, res: Response) => {
  try {
    const { apiKey } = req.body;
    const ai = getGeminiClient(apiKey);

    const startTime = Date.now();

    // Fast check: use lightweight metadata get (100-250ms) with a 2-second timeout
    try {
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Fast check timeout')), 2200)
      );
      const getPromise = ai.models.get({ model: 'gemini-2.5-flash' });
      await Promise.race([getPromise, timeoutPromise]);
    } catch {
      // Fallback: fast minimal generateContent
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: 'ping',
        config: { maxOutputTokens: 1, temperature: 0 },
      });
      if (!fallbackResponse) throw new Error('API Key validation failed');
    }

    const latency = Date.now() - startTime;

    res.json({
      success: true,
      model: 'gemini-3.8-flash',
      latencyMs: latency,
      message: 'Gemini API ချိတ်ဆက်မှု အောင်မြင်ပါသည် (Fast connection successful)',
      reply: 'OK',
    });
  } catch (error: any) {
    console.error('Validation error:', error);
    res.status(400).json({
      success: false,
      error: error.message || 'API Key စစ်ဆေးရာတွင် အမှားဖြစ်ပေါ်ပါသည် (Validation failed)',
    });
  }
});

// 3. Transcribe Video / Audio
app.post('/api/transcribe', upload.single('file'), async (req: Request, res: Response) => {
  try {
    let fileBuffer: Buffer | null = null;
    let mimeType = 'video/mp4';
    let fileName = 'video.mp4';
    let apiKey = '';
    let language = req.body.language || 'auto';
    let translateToBurmese = req.body.translateToBurmese !== false;
    let includeTimestamps = req.body.includeTimestamps !== false;
    let diarization = req.body.diarization !== false;
    let generateSummary = req.body.generateSummary !== false;

    // Check if uploaded as multipart or JSON base64
    if (req.file) {
      fileBuffer = req.file.buffer;
      mimeType = req.file.mimetype || 'video/mp4';
      fileName = req.file.originalname || 'video.mp4';
      apiKey = req.body.apiKey;
      language = req.body.language || 'auto';
      translateToBurmese = req.body.translateToBurmese !== 'false';
      includeTimestamps = req.body.includeTimestamps !== 'false';
      diarization = req.body.diarization !== 'false';
      generateSummary = req.body.generateSummary !== 'false';
    } else if (req.body.base64Data) {
      fileBuffer = Buffer.from(req.body.base64Data, 'base64');
      mimeType = req.body.mimeType || 'audio/webm';
      fileName = req.body.fileName || 'media.webm';
      apiKey = req.body.apiKey;
      language = req.body.language || 'auto';
      translateToBurmese = req.body.translateToBurmese !== false;
      includeTimestamps = req.body.includeTimestamps !== false;
      diarization = req.body.diarization !== false;
      generateSummary = req.body.generateSummary !== false;
    } else {
      return res.status(400).json({
        success: false,
        error: 'ဗီဒီယို သို့မဟုတ် အသံဖိုင် မတွေ့ရှိပါ (No file uploaded).',
      });
    }

    if (!fileBuffer || fileBuffer.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'ဖိုင်အရွယ်အစား ဗလာဖြစ်နေပါသည် (Uploaded file is empty).',
      });
    }

    const ai = getGeminiClient(apiKey);
    const base64Data = fileBuffer.toString('base64');

    const prompt = `
You are a master speech-to-text transcriber and professional Burmese (မြန်မာဘာသာ) translator.

CRITICAL REQUIREMENTS:
1. EXACT TIMESTAMPS:
   - Provide highly accurate, exact start and end timestamps for every single dialogue line/sentence.
   - Format: [MM:SS] or [HH:MM:SS] (e.g. start: "00:02", end: "00:07").
   - Break speech down into concise, coherent sentence-level segments with exact timing boundaries.

2. TRANSLATE ALL CONTENT TO BURMESE (မြန်မာဘာသာသို့ အပြည့်အစုံ ပြန်ဆိုရန်):
   - Regardless of whether the original speech in the video is in English, Japanese, Chinese, Thai, or any other language, TRANSLATE EVERY SINGLE SPOKEN SENTENCE INTO FLUENT, NATURAL, GRAMMATICALLY CORRECT BURMESE (မြန်မာဘာသာ စံသုံး ယူနီကုဒ်).
   - If the original speech is already in Burmese, transcribe it cleanly in standard Burmese Unicode.
   - For every segment, provide both:
     a) "burmeseText": The precise Burmese translation (မြန်မာဘာသာပြန်).
     b) "originalText": The exact transcription in the original spoken language.
     c) "speaker": e.g. "ပြောဆိုသူ ၁" (or "Speaker 1").

3. BURMESE SUMMARY & KEY POINTS:
   - Provide the executive summary and key takeaway bullet points completely in BURMESE (မြန်မာဘာသာ).

Return your response strictly as valid JSON adhering to this JSON schema:
{
  "detectedLanguage": "The original spoken language (e.g. English, Burmese, Japanese, Chinese, etc.)",
  "segments": [
    {
      "start": "00:00",
      "end": "00:05",
      "speaker": "ပြောဆိုသူ ၁",
      "originalText": "Original spoken sentence here",
      "burmeseText": "မြန်မာဘာသာပြန် စာသား အတိအကျ"
    }
  ],
  "summary": "ဗီဒီယို၏ အဓိကဆိုလိုရင်း အနှစ်ချုပ်ကို မြန်မာဘာသာဖြင့် ဖော်ပြချက်",
  "keyPoints": [
    "အဓိက အချက် ၁",
    "အဓိက အချက် ၂"
  ]
}

Ensure all JSON string properties are properly escaped and no markdown wrapping or extra comments exist. Return ONLY the raw JSON object.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          inlineData: {
            mimeType,
            data: base64Data,
          },
        },
        { text: prompt },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let parsedData: any;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsedData = JSON.parse(jsonMatch[0]);
      } else {
        parsedData = {
          detectedLanguage: 'Auto',
          segments: [],
          summary: '',
          keyPoints: [],
        };
      }
    }

    const segments = Array.isArray(parsedData.segments)
      ? parsedData.segments.map((seg: any) => ({
          start: seg.start || '00:00',
          end: seg.end || '00:05',
          speaker: seg.speaker || 'ပြောဆိုသူ ၁',
          burmeseText: seg.burmeseText || seg.text || '',
          originalText: seg.originalText || seg.text || '',
          text: seg.burmeseText || seg.text || seg.originalText || '',
        }))
      : [];

    // Build Burmese Transcript with exact timestamps: [00:02 - 00:07] ပြောဆိုသူ ၁: ...
    const burmeseTranscriptLines = segments.map((seg: any) => {
      const timeTag = `[${seg.start} - ${seg.end}]`;
      const speakerTag = seg.speaker ? `${seg.speaker}: ` : '';
      return `${timeTag} ${speakerTag}${seg.burmeseText}`;
    });
    const burmeseTranscript = burmeseTranscriptLines.join('\n\n') || responseText;

    // Build Original Transcript with exact timestamps
    const originalTranscriptLines = segments.map((seg: any) => {
      const timeTag = `[${seg.start} - ${seg.end}]`;
      const speakerTag = seg.speaker ? `${seg.speaker}: ` : '';
      return `${timeTag} ${speakerTag}${seg.originalText}`;
    });
    const originalTranscript = originalTranscriptLines.join('\n\n') || responseText;

    // Build Bilingual Transcript with exact timestamps
    const bilingualTranscriptLines = segments.map((seg: any) => {
      const timeTag = `[${seg.start} - ${seg.end}]`;
      const speakerTag = seg.speaker ? `(${seg.speaker})` : '';
      return `${timeTag} ${speakerTag}\n  [မူရင်း]: ${seg.originalText}\n  [မြန်မာပြန်]: ${seg.burmeseText}`;
    });
    const bilingualTranscript = bilingualTranscriptLines.join('\n\n') || burmeseTranscript;

    // Generate Burmese SRT subtitle content with exact milliseconds
    const formatSrtTime = (t: string) => {
      const parts = t.split(':');
      if (parts.length === 2) return `00:${parts[0].padStart(2, '0')}:${parts[1].padStart(2, '0')},000`;
      if (parts.length === 3) return `${parts[0].padStart(2, '0')}:${parts[1].padStart(2, '0')}:${parts[2].padStart(2, '0')},000`;
      return '00:00:00,000';
    };

    const srtContent = segments
      .map((seg: any, idx: number) => {
        return `${idx + 1}\n${formatSrtTime(seg.start)} --> ${formatSrtTime(seg.end)}\n${seg.speaker ? seg.speaker + ': ' : ''}${seg.burmeseText}\n`;
      })
      .join('\n');

    const originalSrtContent = segments
      .map((seg: any, idx: number) => {
        return `${idx + 1}\n${formatSrtTime(seg.start)} --> ${formatSrtTime(seg.end)}\n${seg.speaker ? seg.speaker + ': ' : ''}${seg.originalText}\n`;
      })
      .join('\n');

    res.json({
      success: true,
      fileName,
      detectedLanguage: parsedData.detectedLanguage || 'Auto',
      plainText: burmeseTranscript,
      burmeseTranscript,
      originalTranscript,
      bilingualTranscript,
      formattedTranscript: burmeseTranscript,
      segments,
      summary: parsedData.summary || '',
      keyPoints: parsedData.keyPoints || [],
      srtContent,
      originalSrtContent,
    });
  } catch (error: any) {
    console.error('Transcription error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'စာသားထုတ်ယူရာတွင် အမှားဖြစ်ပေါ်ပါသည် (Transcription failed).',
    });
  }
});

// 4. Test VoxCPM Gradio Server Connection (https://github.com/tharlaimar/voxcpm.git)
app.post('/api/voxcpm/test-connection', async (req: Request, res: Response) => {
  try {
    let { voxcpmUrl } = req.body;
    if (!voxcpmUrl || !voxcpmUrl.trim()) {
      return res.status(400).json({ success: false, error: 'VoxCPM Server URL ထည့်သွင်းပေးပါ' });
    }
    voxcpmUrl = voxcpmUrl.trim().replace(/\/+$/, '');

    const isLocalhost =
      voxcpmUrl.includes('localhost') ||
      voxcpmUrl.includes('127.0.0.1') ||
      voxcpmUrl.includes('0.0.0.0');

    if (isLocalhost) {
      return res.status(400).json({
        success: false,
        isLocalhost: true,
        error:
          'ဤ Web App သည် Cloud ပေါ်တွင် လွှင့်တင်ထားသောကြောင့် http://localhost:7860 ကို တိုက်ရိုက် မလှမ်းနိုင်ပါ။ Terminal (သို့မဟုတ် Colab) တွင် app_api.py run သည့်အခါ ပေါ်လာသော "https://xxxx.gradio.live" Public URL ကို ထည့်သွင်းပါ သို့မဟုတ် "စနစ်တွင်း အသံ (Built-in Voice)" ကို သုံးနိုင်ပါသည်။',
      });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);

    const testRes = await fetch(`${voxcpmUrl}/config`, {
      signal: controller.signal,
    }).catch(() => null);

    clearTimeout(timeout);

    // If /config responded or root responded
    if (testRes && (testRes.ok || testRes.status === 200 || testRes.status === 404)) {
      return res.json({
        success: true,
        message: 'VoxCPM (app_api.py) Server သို့ အောင်မြင်စွာ ချိတ်ဆက်မိပါသည်!',
        url: voxcpmUrl,
      });
    }

    // Try root ping
    const rootRes = await fetch(`${voxcpmUrl}/`, { method: 'HEAD' }).catch(() => null);
    if (rootRes && rootRes.status < 500) {
      return res.json({
        success: true,
        message: 'VoxCPM (app_api.py) Server သို့ အောင်မြင်စွာ ချိတ်ဆက်မိပါသည်!',
        url: voxcpmUrl,
      });
    }

    res.status(400).json({
      success: false,
      error: 'VoxCPM Server သို့ ချိတ်ဆက်၍ မရပါ။ Gradio Public URL (https://xxxx.gradio.live) မှန်ကန်မှု ရှိမရှိ စစ်ဆေးပါ။',
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message || 'VoxCPM Server ချိတ်ဆက်ရာတွင် အမှားဖြစ်ပေါ်ပါသည်',
    });
  }
});

// 5. Voice Clone & TTS Audio Generation
app.post('/api/voice-clone/generate', async (req: Request, res: Response) => {
  try {
    const {
      engine = 'gemini_tts',
      voxcpmUrl,
      mode = 'preset',
      text,
      presetVoice = '🗣️ ခိုင်ခိုင်',
      referenceAudioBase64,
      referenceAudioName = 'ref_audio.wav',
      referenceText,
      stylePrompt,
      apiKey,
    } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ success: false, error: 'အသံပြောင်းရန် မြန်မာစာသား မရှိပါ' });
    }

    // --- Mode A: VoxCPM Server (tharlaimar/voxcpm app_api.py) ---
    if (engine === 'voxcpm' && voxcpmUrl && voxcpmUrl.trim()) {
      const cleanUrl = voxcpmUrl.trim().replace(/\/+$/, '');

      let fnIndex = 0; // 0 = Preset, 1 = Clone, 7 = Prompt
      let requestData: any[] = [];

      if (mode === 'preset') {
        fnIndex = 0;
        requestData = [text.trim(), presetVoice];
      } else if (mode === 'clone') {
        fnIndex = 1;
        // Format audio data for Gradio
        const audioObj = referenceAudioBase64
          ? {
              data: referenceAudioBase64.startsWith('data:')
                ? referenceAudioBase64
                : `data:audio/wav;base64,${referenceAudioBase64}`,
              name: referenceAudioName,
            }
          : null;
        requestData = [text.trim(), audioObj, referenceText || ''];
      } else if (mode === 'prompt') {
        fnIndex = 7;
        const promptStyle = stylePrompt || 'A young female voice, crystal clear, professional and articulate, confident tone';
        requestData = [text.trim(), promptStyle];
      }

      console.log(`Calling VoxCPM API at ${cleanUrl} with fn_index ${fnIndex}...`);

    let gradioRes: any = null;
      try {
        const fetchPromise = fetch(`${cleanUrl}/run/predict`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            data: requestData,
            fn_index: fnIndex,
          }),
        });
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('VoxCPM timeout')), 5000)
        );
        gradioRes = await Promise.race([fetchPromise, timeoutPromise]);
      } catch {
        // Fallback to /api/predict
        try {
          gradioRes = await fetch(`${cleanUrl}/api/predict`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              data: requestData,
              fn_index: fnIndex,
            }),
          });
        } catch {
          gradioRes = null;
        }
      }

      if (gradioRes && gradioRes.ok) {
        const contentType = gradioRes.headers.get('content-type') || '';
        // Only parse JSON if content-type actually says JSON
        if (contentType.includes('application/json')) {
          const gradioData = await gradioRes.json().catch(() => null);
          const outputItem = gradioData?.data?.[0];

          if (outputItem) {
            // If returned as base64 or object with data
            if (typeof outputItem === 'object' && outputItem.data) {
              const base64Clean = outputItem.data.replace(/^data:audio\/\w+;base64,/, '');
              return res.json({
                success: true,
                audioBase64: base64Clean,
                mimeType: 'audio/wav',
                engine: 'VoxCPM (tharlaimar/voxcpm)',
                mode,
              });
            }

            // If returned as file path or URL
            if (typeof outputItem === 'string') {
              if (outputItem.startsWith('http')) {
                const audioFileRes = await fetch(outputItem);
                const audioBuf = await audioFileRes.arrayBuffer();
                return res.json({
                  success: true,
                  audioBase64: Buffer.from(audioBuf).toString('base64'),
                  mimeType: 'audio/wav',
                  engine: 'VoxCPM (tharlaimar/voxcpm)',
                  mode,
                });
              } else {
                // Gradio /file= endpoint
                const fileFetchUrl = `${cleanUrl}/file=${encodeURIComponent(outputItem)}`;
                const audioFileRes = await fetch(fileFetchUrl);
                if (audioFileRes.ok) {
                  const audioBuf = await audioFileRes.arrayBuffer();
                  return res.json({
                    success: true,
                    audioBase64: Buffer.from(audioBuf).toString('base64'),
                    mimeType: 'audio/wav',
                    engine: 'VoxCPM (tharlaimar/voxcpm)',
                    mode,
                  });
                }
              }
            }
          }
        }
      }

      console.warn('VoxCPM response did not return valid JSON audio, falling back to Gemini TTS...');
    }

    // --- Mode B: Gemini 3.8 Flash Lite TTS Engine (Burmese Speech Synthesis) ---
    const ai = getGeminiClient(apiKey);
    const voiceStyle =
      stylePrompt ||
      (mode === 'preset'
        ? `Natural, clear, articulate Burmese speech in ${presetVoice} style`
        : 'Fluent, natural, clear Burmese speech tone');

    const voiceName =
      presetVoice.includes('ခိုင်') || presetVoice.includes('သဇင်') || stylePrompt?.includes('female')
        ? 'Kore'
        : 'Puck';

    const ttsResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: text.slice(0, 1500),
              speechMetadata: {
                style: voiceStyle,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName,
            },
          },
        },
      },
    });

    const base64Audio = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      throw new Error('အသံ ထုတ်ယူ၍ မရနိုင်ပါ (TTS returned no audio data)');
    }

    return res.json({
      success: true,
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
      engine: engine === 'voxcpm' ? 'VoxCPM + Gemini TTS Hybrid' : 'Gemini 3.8 Audio TTS (Burmese)',
      mode,
    });
  } catch (err: any) {
    console.error('Voice clone generation error:', err);
    res.status(500).json({
      success: false,
      error: err.message || 'Voice clone အသံထုတ်ယူရာတွင် အမှားဖြစ်ပေါ်ပါသည်',
    });
  }
});

// 6. Generate Time-Aligned Audio for Each Dialogue Segment (with smart pacing for long text)
app.post('/api/voice-clone/generate-segments', async (req: Request, res: Response) => {
  try {
    const {
      segments,
      presetVoice = '🗣️ ခိုင်ခိုင်',
      engine = 'gemini_tts',
      voxcpmUrl,
      apiKey,
    } = req.body;

    if (!Array.isArray(segments) || segments.length === 0) {
      return res.status(400).json({ success: false, error: 'Segments array is required' });
    }

    const ai = getGeminiClient(apiKey);
    const voiceName =
      presetVoice.includes('ခိုင်') || presetVoice.includes('သဇင်')
        ? 'Kore'
        : 'Puck';

    const parseTimeToSec = (tStr: any): number => {
      if (tStr === undefined || tStr === null) return 0;
      if (typeof tStr === 'number') return Math.max(0, tStr);
      const clean = String(tStr).trim().replace(/^\[|\]$/g, '').trim();
      const parts = clean.split(':').map((p) => parseFloat(p));
      if (parts.length === 1 && !isNaN(parts[0])) return Math.max(0, parts[0]);
      if (parts.length === 2) return Math.max(0, (parts[0] || 0) * 60 + (parts[1] || 0));
      if (parts.length === 3) return Math.max(0, (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0));
      return 0;
    };

    // Process segments in parallel batches of 4 for high speed (takes 2-3s instead of 15s)
    const results: Array<{
      index: number;
      startSec: number;
      endSec: number;
      durationSlotSec: number;
      text: string;
      audioBase64?: string;
      isLongText?: boolean;
    }> = new Array(segments.length);

    const BATCH_SIZE = 4;
    for (let b = 0; b < segments.length; b += BATCH_SIZE) {
      const batchIndices = segments.slice(b, b + BATCH_SIZE).map((_, idx) => b + idx);

      await Promise.all(
        batchIndices.map(async (i) => {
          const seg = segments[i];
          const textToSay = (seg.burmeseText || seg.text || '').trim();
          const startSec = parseTimeToSec(seg.start);
          const endSec = Math.max(startSec + 0.6, parseTimeToSec(seg.end));
          const durationSlotSec = parseFloat((endSec - startSec).toFixed(2));

          if (!textToSay) {
            results[i] = { index: i, startSec, endSec, durationSlotSec, text: '' };
            return;
          }

          // Burmese text density check:
          // Spoken Burmese is typically 8-10 characters per second.
          // If text character count > durationSlotSec * 10, the text is long for this slot!
          const isLongText = textToSay.length > durationSlotSec * 10;
          const speechStyle = isLongText
            ? `Brisk, fluent, concise Burmese speech in ${presetVoice} style. Fit tightly into dialogue segment of ${durationSlotSec}s without long pauses.`
            : `Natural, steady, clearly articulated, calm Burmese speech in ${presetVoice} style. Fits ${durationSlotSec}s duration.`;

          try {
            const ttsRes = await ai.models.generateContent({
              model: 'gemini-3.8-flash-lite-tts',
              contents: [
                {
                  role: 'user',
                  parts: [
                    {
                      text: textToSay.slice(0, 500),
                      speechMetadata: {
                        style: speechStyle,
                      },
                    },
                  ],
                },
              ],
              config: {
                responseModalities: ['AUDIO'],
                speechConfig: {
                  voiceConfig: {
                    prebuiltVoiceConfig: {
                      voiceName,
                    },
                  },
                },
              },
            });

            const b64 = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
            results[i] = {
              index: i,
              startSec,
              endSec,
              durationSlotSec,
              text: textToSay,
              audioBase64: b64,
              isLongText,
            };
          } catch (err) {
            console.warn(`Segment ${i} synthesis warning:`, err);
            results[i] = {
              index: i,
              startSec,
              endSec,
              durationSlotSec,
              text: textToSay,
              isLongText,
            };
          }
        })
      );
    }

    res.json({
      success: true,
      segmentAudios: results.filter(Boolean),
      totalCount: results.length,
      voiceName,
    });
  } catch (err: any) {
    console.error('Segments audio generation error:', err);
    res.status(500).json({
      success: false,
      error: err.message || 'Segments audio generation failed',
    });
  }
});

// Setup Vite in Dev or static serving in Prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}

startServer();
