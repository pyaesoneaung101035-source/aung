import React from 'react';
import { X, History, Trash2, ArrowUpRight, FileText, Clock } from 'lucide-react';
import { AppLanguage, TranscriptionResult } from '../types';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  history: TranscriptionResult[];
  onSelect: (item: TranscriptionResult) => void;
  onClearHistory: () => void;
  appLang: AppLanguage;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  history,
  onSelect,
  onClearHistory,
  appLang,
}) => {
  if (!isOpen) return null;
  const isMy = appLang === 'my';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isMy ? 'ယခင် ထုတ်ယူထားသော Transcript မှတ်တမ်းများ' : 'Transcription History'}
              </h3>
              <p className="text-xs text-slate-400">
                {history.length} {isMy ? 'ခု သိမ်းဆည်းထားပါသည်' : 'items saved in local session'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={onClearHistory}
                className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition text-xs flex items-center gap-1"
                title={isMy ? 'မှတ်တမ်း အားလုံးဖျက်မည်' : 'Clear all'}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{isMy ? 'အားလုံးဖျက်' : 'Clear'}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-3 flex-1">
          {history.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <FileText className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm">
                {isMy ? 'ယခင် မှတ်တမ်းများ မရှိသေးပါ' : 'No previous transcripts found'}
              </p>
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onSelect(item);
                  onClose();
                }}
                className="group p-4 rounded-xl bg-slate-950/60 hover:bg-slate-950 border border-slate-800 hover:border-blue-500/50 cursor-pointer transition flex items-center justify-between gap-4"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-white group-hover:text-blue-400 transition truncate">
                      {item.fileName}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300">
                      {item.detectedLanguage}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                    {item.plainText.slice(0, 150)}...
                  </p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-2">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(item.timestamp).toLocaleString()}
                    </span>
                    <span>{item.segments.length} segments</span>
                  </div>
                </div>

                <div className="shrink-0 w-8 h-8 rounded-lg bg-slate-800 group-hover:bg-blue-600 text-slate-400 group-hover:text-white flex items-center justify-center transition">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
