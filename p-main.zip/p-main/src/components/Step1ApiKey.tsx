import React, { useState } from 'react';
import {
  KeyRound,
  Eye,
  EyeOff,
  ShieldCheck,
  ExternalLink,
  ArrowRight,
  Loader2,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Zap,
  Activity,
  RotateCcw,
} from 'lucide-react';
import { AppLanguage } from '../types';

interface Step1ApiKeyProps {
  apiKey: string;
  setApiKey: (key: string) => void;
  apiKeyConnected: boolean;
  onValidateKey: (customKey?: string) => Promise<boolean>;
  isValidating: boolean;
  hasEnvKey: boolean;
  onProceedToStep2: () => void;
  appLang: AppLanguage;
  connectionInfo: { latencyMs?: number; model?: string } | null;
}

export const Step1ApiKey: React.FC<Step1ApiKeyProps> = ({
  apiKey,
  setApiKey,
  apiKeyConnected,
  onValidateKey,
  isValidating,
  hasEnvKey,
  onProceedToStep2,
  appLang,
  connectionInfo,
}) => {
  const [showKey, setShowKey] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const isMy = appLang === 'my';

  const handleConnect = async (keyToUse?: string) => {
    setErrorMsg(null);
    const success = await onValidateKey(keyToUse);
    if (!success) {
      setErrorMsg(
        isMy
          ? 'API Key မှားယွင်းနေပါသည် သို့မဟုတ် ချိတ်ဆက်မှု မအောင်မြင်ပါ။ ပြန်လည်စစ်ဆေးပါ။'
          : 'Invalid API Key or connection failed. Please check your key and try again.'
      );
    }
  };

  const handleUseEnvKey = async () => {
    setApiKey('');
    await handleConnect('');
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden backdrop-blur-xl">
      {/* Decorative background glow */}
      <div className="absolute top-0 right-0 -mt-12 -mr-12 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/25">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-400 bg-blue-500/10 px-2.5 py-0.5 rounded-full border border-blue-500/20">
                {isMy ? 'အဆင့် ၁' : 'Step 1'}
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                <Zap className="w-3 h-3" />
                {isMy ? 'Fast Check Engine (< 0.2s)' : 'Fast Check Engine (< 0.2s)'}
              </span>
              <h2 className="text-xl font-bold text-white">
                {isMy ? 'Gemini API Key ချိတ်ဆက်ခြင်း' : 'Connect Gemini API Key'}
              </h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              {isMy
                ? 'ဗီဒီယို စာသားထုတ်ယူရန် သင်၏ Gemini API Key ကို ထည့်သွင်းပြီး အမြန်စစ်ဆေး ချိတ်ဆက်ပါ'
                : 'Enter your Gemini API key with ultra-fast health-check verification'}
            </p>
          </div>
        </div>

        {apiKeyConnected ? (
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold self-start sm:self-auto shadow-sm">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{isMy ? 'ဆာဗာ ချိတ်ဆက်ပြီး (Server Connected)' : 'Server Connected & Active'}</span>
            {connectionInfo?.latencyMs !== undefined && (
              <span className="ml-1 px-1.5 py-0.5 rounded bg-emerald-500/20 text-[10px] font-mono">
                {connectionInfo.latencyMs}ms
              </span>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-300 text-xs self-start sm:self-auto">
            <Activity className="w-3.5 h-3.5 animate-pulse text-amber-400" />
            <span>{isMy ? 'ချိတ်ဆက်မှု စောင့်ဆိုင်းနေသည်' : 'Awaiting Connection'}</span>
          </div>
        )}
      </div>

      {/* Fast Connection Status Banner if already connected */}
      {apiKeyConnected && (
        <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-900/80 to-teal-950/40 border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg shadow-emerald-950/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-300">
                  {isMy ? '⚡ ဆာဗာ အောင်မြင်စွာ ချိတ်ဆက်ထားပါသည်' : '⚡ Server Connected & Ready'}
                </span>
                <span className="text-[11px] font-mono bg-emerald-950 px-2 py-0.5 rounded text-emerald-400 border border-emerald-800/40">
                  {connectionInfo?.latencyMs ? `${connectionInfo.latencyMs}ms (Ultra Fast)` : 'Fast Check OK'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                {isMy
                  ? 'Gemini 3.8 Flash ဖြင့် စာသားထုတ်ယူခြင်းနှင့် ဘာသာပြန်ခြင်း ပြုလုပ်ရန် အသင့်ဖြစ်ပါပြီ။'
                  : 'Ready for speech-to-text transcription and Burmese translation.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={() => handleConnect(apiKey)}
              disabled={isValidating}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800/90 hover:bg-slate-700 border border-slate-700 transition"
              title="Test connection speed again"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isValidating ? 'animate-spin' : ''}`} />
              <span>{isMy ? 'အမြန် ပြန်စစ်မည်' : 'Re-check Ping'}</span>
            </button>
            <button
              onClick={onProceedToStep2}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 shadow-md shadow-emerald-500/20 transition transform active:scale-95 shrink-0"
            >
              <span>{isMy ? 'အဆင့် ၂ သို့ သွားမည်' : 'Proceed to Step 2'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Body */}
      <div className="mt-6 space-y-6">
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="block text-sm font-medium text-slate-300">
              {isMy ? 'Gemini API Key ထည့်ရန် Box:' : 'Gemini API Key Input Box:'}
            </label>
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-400" />
              {isMy ? 'Enter နှိပ်၍ အမြန် ချိတ်ဆက်နိုင်သည်' : 'Press Enter to fast-connect'}
            </span>
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
              <KeyRound className="h-5 w-5 text-slate-500" />
            </div>
            <input
              type={showKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setErrorMsg(null);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleConnect(apiKey);
                }
              }}
              placeholder={isMy ? 'AIzaSy... သင်၏ API Key ကို ဤနေရာတွင် ရိုက်ထည့်ပါ (Enter နှိပ်ပါ)' : 'Paste your API key here (AIzaSy...) and press Enter'}
              className="w-full pl-11 pr-24 py-3 bg-slate-950/80 border border-slate-700/80 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm transition font-mono"
            />
            <div className="absolute inset-y-0 right-0 pr-2 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition"
                title={showKey ? 'Hide key' : 'Show key'}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
              {apiKey && (
                <button
                  type="button"
                  onClick={() => setApiKey('')}
                  className="px-2 py-1 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition"
                >
                  {isMy ? 'ဖျက်မည်' : 'Clear'}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Error message if validation failed */}
        {errorMsg && (
          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Actions row */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => handleConnect(apiKey)}
              disabled={isValidating || (!apiKey.trim() && !hasEnvKey)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium text-sm text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 shadow-md shadow-blue-600/30 disabled:opacity-50 disabled:cursor-not-allowed transition transform active:scale-[0.98]"
            >
              {isValidating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>{isMy ? 'အမြန် စစ်ဆေးနေသည် (< 0.2s)...' : 'Fast Checking (< 0.2s)...'}</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>{isMy ? 'အမြန် စစ်ဆေး ချိတ်ဆက်မည် (Fast Connect)' : 'Fast Check & Connect'}</span>
                </>
              )}
            </button>

            {hasEnvKey && (
              <button
                type="button"
                onClick={handleUseEnvKey}
                disabled={isValidating}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-medium text-xs text-slate-200 bg-slate-800/90 hover:bg-slate-700 border border-slate-700 shadow-sm transition"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>{isMy ? '⚡ စနစ်တွင်း ဆာဗာ Key ဖြင့် အမြန်ချိတ်မည်' : '⚡ Fast Server Auto-Key'}</span>
              </button>
            )}
          </div>

          <a
            href="https://aistudio.google.com/app/apikey"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 hover:underline transition"
          >
            <span>{isMy ? 'အခမဲ့ Gemini API Key ရယူရန်' : 'Get a free Gemini API Key'}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-800/60">
          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950/40 border border-slate-800/60">
            <Zap className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs text-slate-300">
              {isMy ? 'တုံ့ပြန်ချိန်မြန် (<200ms) စစ်ဆေးမှု' : 'Sub-200ms Instant Ping Check'}
            </span>
          </div>
          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950/40 border border-slate-800/60">
            <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="text-xs text-slate-300">
              {isMy ? 'Gemini 3.8 Flash Multimodal' : 'Gemini 3.8 Flash Multimodal'}
            </span>
          </div>
          <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950/40 border border-slate-800/60">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-xs text-slate-300">
              {isMy ? 'Auto-Connect ဆာဗာ ချိတ်ဆက်ပြီး' : 'Auto-Connect Server Active'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
