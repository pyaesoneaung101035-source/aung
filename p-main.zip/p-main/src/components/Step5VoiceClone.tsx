import React, { useState, useRef } from 'react';
import {
  Mic,
  Sparkles,
  Play,
  Pause,
  Download,
  Volume2,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  FileAudio,
  Radio,
  Sliders,
  RotateCcw,
  Bot,
  Zap,
  Info,
  Layers,
  ArrowRight,
  Film,
  Clock,
} from 'lucide-react';
import { AppLanguage, TranscriptionResult, VoiceCloneMode, VoiceCloneAudioResult } from '../types';
import { buildCompleteTimeAlignedTrack, safeFetchJson } from '../utils/audioSyncHelper';

interface Step5VoiceCloneProps {
  transcriptionResult: TranscriptionResult;
  referenceAudioBase64?: string;
  referenceAudioName?: string;
  appLang: AppLanguage;
  apiKey: string;
  onProceedToStep6?: () => void;
  voiceAudioResult: VoiceCloneAudioResult | null;
  setVoiceAudioResult: (res: VoiceCloneAudioResult | null) => void;
}

export const Step5VoiceClone: React.FC<Step5VoiceCloneProps> = ({
  transcriptionResult,
  referenceAudioBase64,
  referenceAudioName,
  appLang,
  apiKey,
  onProceedToStep6,
  voiceAudioResult,
  setVoiceAudioResult,
}) => {
  const isMy = appLang === 'my';

  // Engine selection: 'gemini_tts' (Built-in, 100% works anytime) vs 'voxcpm' (External GPU / Colab)
  const [selectedEngine, setSelectedEngine] = useState<'gemini_tts' | 'voxcpm'>('gemini_tts');

  // VoxCPM Server State
  const [voxcpmUrl, setVoxcpmUrl] = useState<string>('');
  const [isTestingUrl, setIsTestingUrl] = useState<boolean>(false);
  const [voxcpmConnected, setVoxcpmConnected] = useState<boolean>(false);
  const [connectionMessage, setConnectionMessage] = useState<string | null>(null);

  // Active Mode (matching app_api.py tabs)
  const [mode, setMode] = useState<VoiceCloneMode>('preset');
  const [selectedPresetVoice, setSelectedPresetVoice] = useState<string>('🗣️ ခိုင်ခိုင်');

  // Clone Tab State
  const [customAudioBase64] = useState<string>(referenceAudioBase64 || '');
  const [customAudioName] = useState<string>(referenceAudioName || 'video_audio.wav');
  const [referenceText, setReferenceText] = useState<string>(
    transcriptionResult.segments[0]?.burmeseText || transcriptionResult.segments[0]?.text || ''
  );

  // Prompt Tab State
  const [stylePrompt, setStylePrompt] = useState<string>(
    'A young female voice, crystal clear, professional and articulate, confident tone'
  );

  // Text selection to vocalize
  const [textToVocalize, setTextToVocalize] = useState<string>(
    transcriptionResult.burmeseTranscript
      ? transcriptionResult.segments.map((s) => s.burmeseText || s.text).join('။ ')
      : transcriptionResult.plainText
  );

  // Audio Generation State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [audioResult, setAudioResult] = useState<VoiceCloneAudioResult | null>(null);
  const [syncWithTimestamps, setSyncWithTimestamps] = useState<boolean>(true);
  const [speechPace, setSpeechPace] = useState<number>(1.0);
  const [progressMsg, setProgressMsg] = useState<string>('');

  // Audio Player State
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [showColabGuide, setShowColabGuide] = useState<boolean>(false);

  const isLocalhostEntered =
    voxcpmUrl.includes('localhost') || voxcpmUrl.includes('127.0.0.1') || voxcpmUrl.includes('0.0.0.0');

  // Preset voices matching app_api.py VOICE_DATABASE
  const presetVoices = [
    { id: '🗣️ ခိုင်ခိုင်', label: '🗣️ ခိုင်ခိုင် (Khaing Khaing)', desc: isMy ? 'နွေးထွေးကြည်လင်သော အမျိုးသမီးအသံ' : 'Warm & clear female voice', gender: 'Female' },
    { id: '🗣️ ကျော်ကျော်', label: '🗣️ ကျော်ကျော် (Kyaw Kyaw)', desc: isMy ? 'တည်ငြိမ်ပြတ်သားသော အမျိုးသားအသံ' : 'Calm & articulate male voice', gender: 'Male' },
    { id: '🗣️ မျိုးသန့်', label: '🗣️ မျိုးသန့် (Myo Thant)', desc: isMy ? 'ဩဇာပြည့်ဝသော သတင်းဖတ်အမျိုးသားအသံ' : 'Authoritative male narrator', gender: 'Male' },
    { id: '🗣️ သဇင်', label: '🗣️ သဇင် (Thazin)', desc: isMy ? 'ချိုသာပျော့ပြောင်းသော အမျိုးသမီးအသံ' : 'Soft & sweet female voice', gender: 'Female' },
    { id: '🎙️ ကိုကို (Host)', label: '🎙️ ကိုကို (Host)', desc: isMy ? 'တက်ကြွရွှင်လန်းသော အစီအစဉ်တင်ဆက်သူ' : 'Energetic podcast host', gender: 'Host' },
  ];

  // Prompt style presets matching app_api.py
  const promptPresets = [
    { title: isMy ? '🧑 လူငယ်အမျိုးသား (တည်ငြိမ်)' : '🧑 Young man, calm & clear', prompt: 'A young male voice, calm and clear, medium pace, deep tone' },
    { title: isMy ? '👩 လူငယ်အမျိုးသမီး (ကြည်လင်)' : '👩 Young woman, warm & soft', prompt: 'A young female voice, crystal clear, professional and articulate, confident tone' },
    { title: isMy ? '📰 သတင်းကြေညာသူ (ခိုင်မာ)' : '📰 News anchor, formal', prompt: 'A news anchor voice, formal and authoritative, steady pace, perfect for broadcast' },
    { title: isMy ? '📖 ပုံပြင်ပြောသူ (နက်နဲ)' : '📖 Storyteller, dramatic', prompt: 'A storyteller voice, dramatic and expressive, slow pace, rich and warm tone' },
    { title: isMy ? '😄 ပွဲတင်ဆက်သူ (တက်ကြွ)' : '😄 Cheerful & energetic host', prompt: 'A cheerful host voice, energetic and friendly, fast pace, bright and engaging' },
  ];

  // Test VoxCPM server connection
  const handleTestConnection = async () => {
    if (!voxcpmUrl.trim()) {
      setConnectionMessage(isMy ? '⚠️ VoxCPM Server URL ရိုက်ထည့်ပါ' : 'Please enter VoxCPM URL');
      return;
    }

    if (isLocalhostEntered) {
      setVoxcpmConnected(false);
      setConnectionMessage(
        isMy
          ? '⚠️ http://localhost:7860 သည် သင့်စက်တွင်းလိပ်စာဖြစ်ပြီး Cloud ပေါ်မှ မလှမ်းနိုင်ပါ။ Colab/Terminal တွင် app_api.py run သည့်အခါ ပေါ်လာသော "https://xxxx.gradio.live" Public Link ကို အသုံးပြုပါ သို့မဟုတ် "စနစ်တွင်း အသံစနစ်" ဖြင့် ချက်ချင်းထုတ်ယူပါ။'
          : '⚠️ http://localhost:7860 is local to your machine and cannot be reached by cloud servers. Please use the https://xxxx.gradio.live public share URL, or use the Built-in Engine!'
      );
      return;
    }

    setIsTestingUrl(true);
    setConnectionMessage(null);
    try {
      const data = await safeFetchJson<{ success: boolean; message?: string; error?: string }>('/api/voxcpm/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ voxcpmUrl }),
      });
      if (data.success) {
        setVoxcpmConnected(true);
        setSelectedEngine('voxcpm');
        setConnectionMessage(isMy ? '✅ VoxCPM Server သို့ အောင်မြင်စွာ ချိတ်ဆက်မိပါသည်!' : 'Connected to VoxCPM server!');
      } else {
        setVoxcpmConnected(false);
        setConnectionMessage(data.error || (isMy ? '❌ ချိတ်ဆက်၍ မရပါ။ စစ်ဆေးပါ။' : 'Connection failed'));
      }
    } catch (err: any) {
      setVoxcpmConnected(false);
      setConnectionMessage(err.message || (isMy ? '❌ Server သို့ ချိတ်ဆက်၍ မရပါ' : 'Unable to connect to server'));
    } finally {
      setIsTestingUrl(false);
    }
  };

  // Generate Voice Clone / TTS
  const handleGenerateVoice = async (forceBuiltIn = false) => {
    if (!textToVocalize.trim()) return;

    setIsGenerating(true);
    setGenerationError(null);
    setProgressMsg(isMy ? 'အသံဖန်တီးနေပါသည်...' : 'Generating audio...');

    const engineToUse = forceBuiltIn || selectedEngine === 'gemini_tts' || !voxcpmConnected ? 'gemini_tts' : 'voxcpm';

    // 1. Time-Aligned Track generation (Guarantees speech starts at exact timestamps e.g. 00:00 -> 00:06, 00:06 -> 00:10)
    if (
      syncWithTimestamps &&
      transcriptionResult.segments &&
      transcriptionResult.segments.length > 0 &&
      (engineToUse === 'gemini_tts' || mode === 'preset')
    ) {
      try {
        const alignedResult = await buildCompleteTimeAlignedTrack({
          segments: transcriptionResult.segments,
          presetVoice: selectedPresetVoice,
          apiKey,
          speechSpeed: speechPace,
          onProgress: (m) => setProgressMsg(m),
        });

        setAudioResult(alignedResult);
        setVoiceAudioResult(alignedResult);
        setIsPlaying(false);
        setIsGenerating(false);
        return;
      } catch (err: any) {
        console.warn('Timestamp alignment failed:', err);
        setGenerationError(
          err.message || (isMy ? 'စာတန်းထိုး အပိုင်းလိုက် အသံထုတ်ယူရာတွင် အမှားဖြစ်ပေါ်ပါသည်' : 'Time-aligned voice generation failed')
        );
        setIsGenerating(false);
        return;
      }
    }

    try {
      const data = await safeFetchJson<{
        success: boolean;
        audioBase64?: string;
        engine?: string;
        error?: string;
      }>('/api/voice-clone/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          engine: engineToUse,
          voxcpmUrl: engineToUse === 'voxcpm' ? voxcpmUrl : undefined,
          mode,
          text: textToVocalize,
          presetVoice: selectedPresetVoice,
          referenceAudioBase64: customAudioBase64,
          referenceAudioName: customAudioName,
          referenceText,
          stylePrompt,
          apiKey,
        }),
      });

      if (!data.success || !data.audioBase64) {
        throw new Error(data.error || 'အသံထုတ်ယူရာတွင် အမှားဖြစ်ပေါ်ပါသည်');
      }

      // Create audio blob url
      const byteCharacters = atob(data.audioBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'audio/wav' });
      const url = URL.createObjectURL(blob);

      const resultObj: VoiceCloneAudioResult = {
        id: 'voice_' + Date.now(),
        audioUrl: url,
        base64: data.audioBase64,
        mimeType: 'audio/wav',
        generatedText: textToVocalize,
        voiceName: mode === 'preset' ? selectedPresetVoice : mode === 'clone' ? 'Cloned Voice' : 'Custom Style Voice',
        engine: data.engine || (engineToUse === 'voxcpm' ? 'VoxCPM (tharlaimar/voxcpm)' : 'Gemini Burmese Voice Engine'),
        mode,
        timestamp: Date.now(),
      };

      setAudioResult(resultObj);
      setVoiceAudioResult(resultObj);
      setIsPlaying(false);
    } catch (err: any) {
      console.error('Voice clone error:', err);
      setGenerationError(err.message || 'အသံထုတ်ယူရာတွင် အမှားဖြစ်ပေါ်ပါသည်');
    } finally {
      setIsGenerating(false);
    }
  };

  // Audio Playback Controls
  const togglePlayPause = () => {
    if (!audioPlayerRef.current) return;
    if (isPlaying) {
      audioPlayerRef.current.pause();
      setIsPlaying(false);
    } else {
      audioPlayerRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (audioPlayerRef.current) {
      audioPlayerRef.current.playbackRate = speed;
    }
  };

  const downloadAudioFile = () => {
    if (!audioResult) return;
    const a = document.createElement('a');
    a.href = audioResult.audioUrl;
    a.download = `burmese_voice_clone_${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatAudioTime = (sec: number): string => {
    if (isNaN(sec)) return '00:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden backdrop-blur-xl">
      {/* Background glow */}
      <div className="absolute top-0 right-0 -mt-16 -mr-16 w-80 h-80 bg-fuchsia-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-fuchsia-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-fuchsia-500/25">
            <Mic className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-fuchsia-400 bg-fuchsia-500/10 px-2.5 py-0.5 rounded-full border border-fuchsia-500/20">
                {isMy ? 'အဆင့် ၅' : 'Step 5'}
              </span>
              <h2 className="text-xl font-bold text-white">
                {isMy ? 'Burmese Voice Clone & TTS ဖြင့် အသံဖန်တီးခြင်း' : 'Burmese Voice Clone & TTS'}
              </h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              {isMy
                ? 'ထွက်လာသော မြန်မာဘာသာ Transcript များကို Voice Clone အသံဖြင့် သဘာဝကျစွာ ဖတ်ကြားထုတ်လုပ်ပါ'
                : 'Synthesize Burmese transcripts into realistic audio with voice cloning'}
            </p>
          </div>
        </div>

        {/* Engine status pill */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowColabGuide(!showColabGuide)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-fuchsia-300 border border-slate-700 transition"
          >
            <ExternalLink className="w-3.5 h-3.5 text-fuchsia-400" />
            <span>{isMy ? 'VoxCPM Colab လမ်းညွှန်' : 'Colab Setup Guide'}</span>
          </button>
        </div>
      </div>

      {/* Engine Selection: Built-in (Always ready) vs VoxCPM (Gradio Public Link) */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Engine 1: Built-in Engine */}
        <button
          type="button"
          onClick={() => setSelectedEngine('gemini_tts')}
          className={`p-4 rounded-xl border text-left transition flex items-start gap-3.5 cursor-pointer ${
            selectedEngine === 'gemini_tts'
              ? 'bg-emerald-500/15 border-emerald-500 ring-1 ring-emerald-500 shadow-lg shadow-emerald-500/10'
              : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400'
          }`}
        >
          <div
            className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
              selectedEngine === 'gemini_tts' ? 'bg-emerald-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-400'
            }`}
          >
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className={`text-xs font-bold ${selectedEngine === 'gemini_tts' ? 'text-emerald-300' : 'text-slate-200'}`}>
                {isMy ? '🌟 စနစ်တွင်း AI အသံစနစ် (Built-in Voice)' : '🌟 Built-in Burmese Voice Engine'}
              </span>
              <span className="px-1.5 py-0.2 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
                {isMy ? 'အသင့်သုံးနိုင်သည်' : 'Always Ready'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {isMy
                ? 'Server/Colab ဖွင့်စရာမလိုဘဲ မြန်မာစကားပြော အသံများကို ချက်ချင်း ၁-Click အဆင်သင့် ထုတ်ပေးနိုင်ပါသည်'
                : 'Zero setup required. Generates realistic Burmese audio instantly out of the box.'}
            </p>
          </div>
        </button>

        {/* Engine 2: VoxCPM Remote GPU / Colab */}
        <button
          type="button"
          onClick={() => setSelectedEngine('voxcpm')}
          className={`p-4 rounded-xl border text-left transition flex items-start gap-3.5 cursor-pointer ${
            selectedEngine === 'voxcpm'
              ? 'bg-fuchsia-600/15 border-fuchsia-500 ring-1 ring-fuchsia-500 shadow-lg shadow-fuchsia-500/10'
              : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-400'
          }`}
        >
          <div
            className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
              selectedEngine === 'voxcpm' ? 'bg-fuchsia-600 text-white font-bold' : 'bg-slate-800 text-slate-400'
            }`}
          >
            <Zap className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className={`text-xs font-bold ${selectedEngine === 'voxcpm' ? 'text-fuchsia-300' : 'text-slate-200'}`}>
                {isMy ? '⚡ VoxCPM Server (tharlaimar/voxcpm)' : '⚡ VoxCPM Server (app_api.py)'}
              </span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] font-medium border ${
                voxcpmConnected
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                {voxcpmConnected ? (isMy ? 'ချိတ်ဆက်ပြီး' : 'Connected') : (isMy ? 'Colab/GPU လိုအပ်' : 'Requires Public URL')}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {isMy
                ? 'Colab/GPU တွင် app_api.py run ၍ ထွက်လာသော https://xxxx.gradio.live link ဖြင့် ချိတ်ဆက်သုံးနိုင်သည်'
                : 'Connect to your running app_api.py Gradio instance for custom GPU model execution.'}
            </p>
          </div>
        </button>
      </div>

      {/* VoxCPM Server Config Card (Shown when selectedEngine is voxcpm OR user entered localhost) */}
      {(selectedEngine === 'voxcpm' || isLocalhostEntered) && (
        <div className="mt-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-200">
              <Zap className="w-4 h-4 text-fuchsia-400" />
              <span>{isMy ? 'VoxCPM Public Gradio URL ထည့်ပါ:' : 'VoxCPM Gradio Public URL:'}</span>
            </div>
            <span className="text-[11px] text-slate-400">
              ဥပမာ: <code className="text-emerald-400">https://xxxx.gradio.live</code>
            </span>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <input
              type="text"
              value={voxcpmUrl}
              onChange={(e) => {
                setVoxcpmUrl(e.target.value);
                setVoxcpmConnected(false);
              }}
              placeholder="https://xxxxxxxx.gradio.live"
              className="flex-1 px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-fuchsia-500 font-mono"
            />
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTestingUrl}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-fuchsia-600 hover:bg-fuchsia-500 shadow-md shadow-fuchsia-600/20 transition shrink-0 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {isTestingUrl && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
              <span>{isMy ? 'ချိတ်ဆက်မှု စစ်ဆေးမည်' : 'Connect & Test'}</span>
            </button>
          </div>

          {/* Localhost Explanation Helper Card */}
          {isLocalhostEntered && (
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-300">
                <Info className="w-4 h-4 shrink-0 text-amber-400" />
                <span>
                  {isMy
                    ? '⚠️ "http://localhost:7860" ချိတ်ဆက်မရခြင်း အကြောင်းရင်းနှင့် ဖြေရှင်းနည်း'
                    : 'Why http://localhost:7860 cannot connect & how to solve:'}
                </span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                {isMy
                  ? 'ဤ Web App သည် Cloud ပေါ်တွင် လွှင့်တင်ထားသောကြောင့် သင့်စက်ထဲရှိ `localhost:7860` သို့ Cloud မှ တိုက်ရိုက် လှမ်းခေါ်၍ မရပါ။'
                  : 'Because this app runs in Cloud Run, it cannot directly reach "localhost" on your home computer.'}
              </p>
              <div className="pt-1 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedEngine('gemini_tts');
                    setVoxcpmUrl('');
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 shadow-sm transition"
                >
                  {isMy ? '👉 စနစ်တွင်း အသံ (Built-in Voice) ဖြင့် ချက်ချင်းထုတ်မည်' : 'Use Built-in Engine Instead'}
                </button>
                <span className="text-[11px] text-slate-400">
                  {isMy
                    ? 'သို့မဟုတ် Terminal/Colab မှ `https://xxxx.gradio.live` link ကို ကူးယူထည့်ပါ'
                    : 'Or paste your https://xxxx.gradio.live public share link'}
                </span>
              </div>
            </div>
          )}

          {connectionMessage && !isLocalhostEntered && (
            <p className="text-xs text-slate-300 font-medium pt-1">
              {connectionMessage}
            </p>
          )}
        </div>
      )}

      {/* Google Colab Instructions Dropdown */}
      {showColabGuide && (
        <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-fuchsia-500/30 text-xs text-slate-300 space-y-2.5 animate-in fade-in duration-150">
          <div className="flex items-center justify-between font-semibold text-fuchsia-300">
            <span>🚀 VoxCPM app_api.py ကို Google Colab တွင် Free GPU ဖြင့် Run နည်း</span>
            <a
              href="https://github.com/tharlaimar/voxcpm"
              target="_blank"
              rel="noreferrer"
              className="text-fuchsia-400 hover:underline flex items-center gap-1"
            >
              <span>GitHub Repo</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <ol className="list-decimal pl-5 space-y-1 text-slate-400">
            <li>Google Colab (colab.research.google.com) ဖွင့်ပြီး Runtime ကို <strong>T4 GPU</strong> ရွေးပါ။</li>
            <li>Colab Cell တွင် <code className="text-fuchsia-300">!git clone https://github.com/tharlaimar/voxcpm.git</code> ဟု Run ပါ။</li>
            <li>ထို့နောက် <code className="text-fuchsia-300">cd voxcpm && python app_api.py</code> ကို Run ပါ။</li>
            <li>
              Output တွင် <code className="text-emerald-400">Running on public URL: https://xxxxxxxx.gradio.live</code> ပေါ်လာပါမည်။
            </li>
            <li>ထို <strong>https://xxxxxxxx.gradio.live</strong> လင့်ခ်ကို အထက်ပါ URL Box တွင် ထည့်သွင်း ချိတ်ဆက်ပါ။</li>
            <li>Colab မ run ထားပါကလည်း အပေါ်ရှိ <strong>"စနစ်တွင်း AI အသံ (Built-in Voice)"</strong> ဖြင့် အသံကို ချက်ချင်း ထုတ်ယူနိုင်ပါသည်။</li>
          </ol>
        </div>
      )}

      {/* 3 Voice Tabs matching app_api.py */}
      <div className="mt-6 border-b border-slate-800 flex items-center gap-2">
        <button
          onClick={() => setMode('preset')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            mode === 'preset'
              ? 'border-fuchsia-500 text-fuchsia-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>🎭 {isMy ? 'အသင့်သုံး အသံများ (Preset Voice)' : 'Preset Voice'}</span>
        </button>

        <button
          onClick={() => setMode('clone')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            mode === 'clone'
              ? 'border-fuchsia-500 text-fuchsia-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>🎤 {isMy ? 'အသံ Clone မည် (Voice Clone)' : 'Voice Clone'}</span>
        </button>

        <button
          onClick={() => setMode('prompt')}
          className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
            mode === 'prompt'
              ? 'border-fuchsia-500 text-fuchsia-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>✨ {isMy ? 'ပုံစံဖော်အသံ (Prompt Voice)' : 'Prompt Voice'}</span>
        </button>
      </div>

      {/* Tab 1: Preset Voice */}
      {mode === 'preset' && (
        <div className="mt-5 space-y-4">
          <p className="text-xs text-slate-400">
            {isMy
              ? 'tharlaimar/voxcpm တွင် ပါဝင်သော နာမည်ကျော် မြန်မာ စကားပြော အသံများကို ရွေးချယ်ပါ:'
              : 'Choose one of the built-in Burmese voice presets from VoxCPM:'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {presetVoices.map((voice) => (
              <label
                key={voice.id}
                className={`p-3.5 rounded-xl border text-xs cursor-pointer transition flex items-start gap-3 ${
                  selectedPresetVoice === voice.id
                    ? 'bg-fuchsia-600/15 border-fuchsia-500 text-white font-medium shadow-md shadow-fuchsia-500/10'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="presetVoice"
                  value={voice.id}
                  checked={selectedPresetVoice === voice.id}
                  onChange={() => setSelectedPresetVoice(voice.id)}
                  className="mt-0.5 text-fuchsia-600 focus:ring-fuchsia-500"
                />
                <div>
                  <div className="font-bold text-slate-100">{voice.label}</div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{voice.desc}</p>
                </div>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Clone Voice */}
      {mode === 'clone' && (
        <div className="mt-5 space-y-4 bg-slate-950/50 p-5 rounded-2xl border border-slate-800">
          <p className="text-xs text-slate-400">
            {isMy
              ? 'သင်တင်ထားသော ဗီဒီယိုမှ အသံ (Reference Audio) ကို ယူ၍ ၎င်းအသံနှင့် အတိအကျတူအောင် Voice Clone ပြုလုပ်ပါမည်:'
              : 'Zero-shot voice cloning using your video audio reference and text:'}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                🎵 {isMy ? 'Reference အသံဖိုင် (Clone မည့် မူရင်းအသံ)' : 'Reference Audio Source'}:
              </label>
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 truncate">
                  <FileAudio className="w-4 h-4 text-fuchsia-400 shrink-0" />
                  <span className="truncate text-slate-200 font-mono">
                    {customAudioName || transcriptionResult.fileName}
                  </span>
                </div>
                <span className="px-2 py-0.5 text-[10px] rounded bg-emerald-500/20 text-emerald-400 font-medium shrink-0">
                  {isMy ? 'အသင့်ရှိသည်' : 'Ready'}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                📄 {isMy ? 'Reference Text (အသံဖိုင်ထဲတွင် ပြောထားသော စာသား)' : 'Reference Text'}:
              </label>
              <input
                type="text"
                value={referenceText}
                onChange={(e) => setReferenceText(e.target.value)}
                placeholder="Reference ဖိုင်ထဲတွင် ပြောထားသော စာသား..."
                className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-fuchsia-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Prompt Voice */}
      {mode === 'prompt' && (
        <div className="mt-5 space-y-4 bg-slate-950/50 p-5 rounded-2xl border border-slate-800">
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300">
              💡 {isMy ? 'နမူနာ အသံပုံစံ (Voice Style Presets) များ:' : 'Voice Style Presets:'}
            </label>
            <div className="flex flex-wrap gap-2">
              {promptPresets.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setStylePrompt(p.prompt)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 text-fuchsia-300 border border-slate-800 hover:border-fuchsia-500/40 transition"
                >
                  {p.title}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              🎨 {isMy ? 'Voice Style Prompt စာသား:' : 'Voice Style Description:'}
            </label>
            <textarea
              rows={2}
              value={stylePrompt}
              onChange={(e) => setStylePrompt(e.target.value)}
              className="w-full p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-fuchsia-500 resize-none font-mono"
            />
          </div>
        </div>
      )}

      {/* Text To Vocalize Editor */}
      <div className="mt-6 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <label className="font-semibold text-slate-300">
            📝 {isMy ? 'အသံထွက်စေလိုသော မြန်မာစာသား (Text to Speak):' : 'Burmese Text to Vocalize:'}
          </label>
          <button
            type="button"
            onClick={() => {
              setTextToVocalize(
                transcriptionResult.segments.map((s) => s.burmeseText || s.text).join('။ ')
              );
            }}
            className="text-fuchsia-400 hover:underline flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>{isMy ? 'Transcript အပြည့်အစုံ ပြန်ဖြည့်မည်' : 'Reset to Full Transcript'}</span>
          </button>
        </div>

        <textarea
          rows={4}
          value={textToVocalize}
          onChange={(e) => setTextToVocalize(e.target.value)}
          placeholder="အသံထွက်လိုသော မြန်မာစာသား ထည့်ပါ..."
          className="w-full p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-fuchsia-500 leading-relaxed resize-none"
        />
      </div>

      {/* Generation Error */}
      {generationError && (
        <div className="mt-4 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{generationError}</span>
          </div>
          <button
            type="button"
            onClick={() => handleGenerateVoice(true)}
            className="px-3 py-1 rounded-lg text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 shrink-0 transition"
          >
            {isMy ? 'စနစ်တွင်း အသံဖြင့် ချက်ချင်းထုတ်မည်' : 'Retry with Built-in Engine'}
          </button>
        </div>
      )}

      {/* Timestamp-Aligned Dubbing Setting */}
      {transcriptionResult.segments && transcriptionResult.segments.length > 0 && (
        <div className="mt-5 p-4 rounded-xl bg-slate-950/70 border border-fuchsia-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-fuchsia-400" />
              <span className="text-xs font-bold text-white">
                {isMy ? 'စာတန်းထိုး အချိန်ကိုက် စနစ် (Timestamp-Aligned Dubbing)' : 'Timestamp-Aligned Dubbing'}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                {isMy ? 'အကြံပြုထားသည် (Recommended)' : 'Recommended'}
              </span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={syncWithTimestamps}
                onChange={(e) => setSyncWithTimestamps(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-fuchsia-600"></div>
            </label>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {isMy
              ? '💡 ဥပမာ: [00:00 - 00:06] တွင် "မင်္ဂလာပါ" ပြောပြီး၊ [00:06 - 00:10] တွင် "ဘာတွေလုပ်နေလဲ" စသည်ဖြင့် စကားပြောတစ်ခုချင်းစီ၏ စတင်ချိန် [MM:SS] တိုင်းတွင် အတိအကျ ကွက်တိကျစေရန် စနစ်မှ အလိုအလျောက် အချိန်ကိုက် ညှိပေးပါမည်။'
              : 'Automatically places each sentence at its exact subtitle cue timestamp with natural pauses in between.'}
          </p>

          {/* Speech Pace Selection */}
          <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs text-slate-400 font-medium">
              {isMy ? 'စကားပြော အမြန်နှုန်း (Speech Pace):' : 'Speech Pace:'}
            </span>
            <div className="flex items-center gap-1.5">
              {[
                { pace: 0.85, label: isMy ? '🐢 ဖြည်းဖြည်း (0.85x)' : 'Calm (0.85x)' },
                { pace: 1.0, label: isMy ? '🗣️ ပုံမှန် (1.0x)' : 'Normal (1.0x)' },
                { pace: 1.15, label: isMy ? '⚡ အမြန် (1.15x)' : 'Brisk (1.15x)' },
              ].map((item) => (
                <button
                  key={item.pace}
                  type="button"
                  onClick={() => setSpeechPace(item.pace)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                    speechPace === item.pace
                      ? 'bg-fuchsia-600 text-white shadow-sm'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Action CTAs */}
      <div className="mt-6 flex flex-col sm:flex-row items-center gap-3">
        <button
          onClick={() => handleGenerateVoice(false)}
          disabled={isGenerating || !textToVocalize.trim()}
          className="flex-1 w-full flex items-center justify-center gap-3 py-4 px-6 rounded-2xl text-sm font-bold text-white bg-gradient-to-r from-fuchsia-600 via-pink-600 to-indigo-600 hover:from-fuchsia-500 hover:via-pink-500 hover:to-indigo-500 shadow-xl shadow-fuchsia-600/30 transition transform active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          {isGenerating ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>{isMy ? 'အသံဖန်တီးနေပါသည်...' : 'Generating Audio...'}</span>
            </>
          ) : (
            <>
              <Mic className="w-5 h-5 text-fuchsia-200" />
              <span>
                {selectedEngine === 'voxcpm' && voxcpmConnected
                  ? (isMy ? '🎙️ VoxCPM ဖြင့် အသံဖန်တီးမည်' : 'Generate with VoxCPM')
                  : (isMy ? '🎙️ အသံ စတင်ဖန်တီးမည် (Generate Audio)' : 'Generate Burmese Voice Audio')}
              </span>
            </>
          )}
        </button>

        {/* 1-Click Fast Instant Fallback Button */}
        {selectedEngine === 'voxcpm' && !voxcpmConnected && (
          <button
            type="button"
            onClick={() => handleGenerateVoice(true)}
            disabled={isGenerating || !textToVocalize.trim()}
            className="w-full sm:w-auto px-5 py-4 rounded-2xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 shadow-lg shadow-emerald-500/20 transition transform active:scale-95 shrink-0 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isMy ? 'စနစ်တွင်း အသံဖြင့် ချက်ချင်းထုတ်မည်' : 'Generate with Built-in Engine'}</span>
          </button>
        )}
      </div>

      {/* Generated Audio Player Card */}
      {audioResult && (
        <div className="mt-6 p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-fuchsia-500/40 shadow-2xl space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-fuchsia-500/20 text-fuchsia-400 flex items-center justify-center shrink-0">
                <Volume2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>{audioResult.voiceName}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-fuchsia-500/20 text-fuchsia-300 font-mono">
                    {audioResult.engine}
                  </span>
                </h4>
                <div className="flex flex-wrap items-center gap-2 mt-0.5">
                  <p className="text-xs text-slate-400">
                    {isMy ? 'မြန်မာဘာသာ အသံဖိုင် ဖန်တီးပြီးပါပြီ' : 'Burmese audio ready'}
                  </p>
                  {audioResult.isTimeAligned && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>{isMy ? 'စာတန်းထိုး အချိန်ကိုက် ညှိပြီး (00:00 -> 00:06 -> 00:10)' : 'Timestamp-Aligned'}</span>
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Download audio */}
            <button
              onClick={downloadAudioFile}
              className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-fuchsia-400 to-pink-400 hover:from-fuchsia-300 hover:to-pink-300 shadow-md shadow-fuchsia-500/20 transition transform active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isMy ? 'အသံဖိုင် ဒေါင်းလုဒ် (.WAV)' : 'Download Audio (.WAV)'}</span>
            </button>
          </div>

          {/* HTML5 Audio Player */}
          <audio
            ref={audioPlayerRef}
            src={audioResult.audioUrl}
            onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
            onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
            onEnded={() => setIsPlaying(false)}
            className="hidden"
          />

          {/* Custom Audio Player Controls */}
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <button
              onClick={togglePlayPause}
              className="w-12 h-12 rounded-xl bg-fuchsia-600 hover:bg-fuchsia-500 text-white flex items-center justify-center shadow-lg shadow-fuchsia-600/30 transition transform active:scale-95 shrink-0"
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
            </button>

            {/* Timeline slider */}
            <div className="flex-1 w-full space-y-1">
              <input
                type="range"
                min={0}
                max={duration || 100}
                value={currentTime}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setCurrentTime(val);
                  if (audioPlayerRef.current) {
                    audioPlayerRef.current.currentTime = val;
                  }
                }}
                className="w-full accent-fuchsia-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                <span>{formatAudioTime(currentTime)}</span>
                <span>{formatAudioTime(duration)}</span>
              </div>
            </div>

            {/* Playback speed pills */}
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-[11px] shrink-0">
              {[0.8, 1, 1.25, 1.5].map((s) => (
                <button
                  key={s}
                  onClick={() => handleSpeedChange(s)}
                  className={`px-2 py-0.5 rounded-lg transition ${
                    playbackSpeed === s
                      ? 'bg-fuchsia-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>
          </div>

          {/* Proceed to Step 6 Dubbing CTA */}
          {onProceedToStep6 && (
            <div className="pt-2 border-t border-slate-800/80">
              <button
                type="button"
                onClick={onProceedToStep6}
                className="w-full flex items-center justify-center gap-2.5 py-3.5 px-5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-rose-500 via-pink-600 to-indigo-600 hover:from-rose-400 hover:to-indigo-500 shadow-lg shadow-rose-500/25 transition transform active:scale-98 cursor-pointer"
              >
                <Film className="w-4 h-4" />
                <span>{isMy ? 'အဆင့် ၆: Video ထဲသို့ ဤအသံ ထည့်သွင်းပေါင်းစပ်မည် (Dub into Video) ➔' : 'Proceed to Step 6: Dub into Video ➔'}</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
