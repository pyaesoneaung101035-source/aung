import React from 'react';
import { Sparkles, KeyRound, CheckCircle2, History, Languages } from 'lucide-react';
import { AppLanguage } from '../types';

interface HeaderProps {
  apiKeyConnected: boolean;
  appLang: AppLanguage;
  setAppLang: (lang: AppLanguage) => void;
  onOpenHistory: () => void;
  historyCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  apiKeyConnected,
  appLang,
  setAppLang,
  onOpenHistory,
  historyCount,
}) => {
  const isMy = appLang === 'my';

  return (
    <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 p-[2px] shadow-lg shadow-blue-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-lg text-white tracking-tight">
                Gemini Video Transcriber
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-medium tracking-wide bg-blue-500/10 text-blue-400 border border-blue-500/30 rounded-full">
                Gemini 3.8 Flash
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {isMy ? 'ဗီဒီယိုမှ စာသားနှင့် TXT အလိုအလျောက် ထုတ်ယူစနစ်' : 'AI Video to Text & TXT Converter'}
            </p>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          {/* Status Indicator */}
          <div
            className={`hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border ${
              apiKeyConnected
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
            }`}
          >
            {apiKeyConnected ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isMy ? 'API ချိတ်ဆက်ထားသည်' : 'API Connected'}</span>
              </>
            ) : (
              <>
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                <span>{isMy ? 'API Key မချိတ်ရသေးပါ' : 'API Key Required'}</span>
              </>
            )}
          </div>

          {/* History button */}
          <button
            onClick={onOpenHistory}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
            title={isMy ? 'ယခင်မှတ်တမ်းများ' : 'History'}
          >
            <History className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">{isMy ? 'မှတ်တမ်း' : 'History'}</span>
            {historyCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] flex items-center justify-center font-bold">
                {historyCount}
              </span>
            )}
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => setAppLang(isMy ? 'en' : 'my')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          >
            <Languages className="w-3.5 h-3.5 text-indigo-400" />
            <span>{isMy ? 'English' : 'မြန်မာ'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
