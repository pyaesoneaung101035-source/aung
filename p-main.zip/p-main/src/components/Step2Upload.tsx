import React, { useRef, useState } from 'react';
import { UploadCloud, Video, FileAudio, Trash2, ArrowRight, Play, Film, CheckCircle2 } from 'lucide-react';
import { AppLanguage } from '../types';
import { generateTestSpeechBlob } from '../utils/sampleData';

interface Step2UploadProps {
  selectedFile: File | null;
  setSelectedFile: (file: File | null) => void;
  videoPreviewUrl: string | null;
  setVideoPreviewUrl: (url: string | null) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  onProceedToStep3: () => void;
  appLang: AppLanguage;
  videoDuration: number;
  setVideoDuration: (dur: number) => void;
}

export const Step2Upload: React.FC<Step2UploadProps> = ({
  selectedFile,
  setSelectedFile,
  videoPreviewUrl,
  setVideoPreviewUrl,
  videoRef,
  onProceedToStep3,
  appLang,
  videoDuration,
  setVideoDuration,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isMy = appLang === 'my';

  const handleFileChange = (file: File) => {
    setSelectedFile(file);
    if (videoPreviewUrl) {
      URL.revokeObjectURL(videoPreviewUrl);
    }
    const url = URL.createObjectURL(file);
    setVideoPreviewUrl(url);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('video/') || file.type.startsWith('audio/')) {
        handleFileChange(file);
      }
    }
  };

  const handleSelectSample = () => {
    const sample = generateTestSpeechBlob('Burmese_Lecture_Demo_Sample');
    handleFileChange(sample);
  };

  const handleClear = () => {
    if (videoPreviewUrl) {
      URL.revokeObjectURL(videoPreviewUrl);
    }
    setSelectedFile(null);
    setVideoPreviewUrl(null);
    setVideoDuration(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  const formatTime = (secs: number): string => {
    if (!secs || isNaN(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden backdrop-blur-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25">
            <Video className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20">
                {isMy ? 'အဆင့် ၂' : 'Step 2'}
              </span>
              <h2 className="text-xl font-bold text-white">
                {isMy ? 'Video ဖိုင် Upload ပြုလုပ်ခြင်း' : 'Upload Video File'}
              </h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              {isMy
                ? 'စာသားပြောင်းလိုသော Video (MP4, WebM, MOV) သို့မဟုတ် Audio ဖိုင်ကို တင်ပါ'
                : 'Upload the video (MP4, WebM, MOV) or audio file you want to transcribe'}
            </p>
          </div>
        </div>

        {selectedFile && (
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 text-xs font-semibold self-start sm:self-auto">
            <CheckCircle2 className="w-4 h-4 text-indigo-400" />
            <span>{isMy ? 'ဖိုင် အဆင်သင့်ရှိပါသည်' : 'Video Ready'}</span>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="mt-6 space-y-6">
        {!selectedFile ? (
          /* Dropzone */
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all duration-200 group ${
              isDragging
                ? 'border-indigo-500 bg-indigo-500/10 scale-[1.01]'
                : 'border-slate-700/80 hover:border-indigo-500/70 bg-slate-950/40 hover:bg-slate-950/60'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="video/mp4,video/webm,video/quicktime,video/x-matroska,video/avi,audio/mpeg,audio/wav,audio/m4a,audio/webm"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleFileChange(e.target.files[0]);
                }
              }}
              className="hidden"
            />

            <div className="w-16 h-16 rounded-2xl bg-indigo-600/15 text-indigo-400 border border-indigo-500/30 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 group-hover:bg-indigo-600/25 transition">
              <UploadCloud className="w-8 h-8" />
            </div>

            <h3 className="text-base font-semibold text-white mb-1">
              {isMy ? 'ဗီဒီယိုဖိုင်ကို ဤနေရာသို့ ဆွဲထည့်ပါ သို့မဟုတ် နှိပ်၍ရွေးပါ' : 'Drag & drop your video here, or browse files'}
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto mb-5">
              {isMy
                ? 'MP4, WebM, MOV, MKV, AVI သို့မဟုတ် Audio (MP3, WAV, M4A) ဖိုင်များကို ထောက်ပံ့ပါသည်'
                : 'Supports MP4, WebM, MOV, MKV, AVI, and audio formats (MP3, WAV, M4A)'}
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-600/20 transition"
              >
                {isMy ? 'ဖိုင် ရွေးချယ်မည် (Browse)' : 'Choose File'}
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelectSample();
                }}
                className="px-4 py-2 rounded-xl text-xs font-medium text-indigo-300 bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-700/50 transition inline-flex items-center gap-1.5"
              >
                <Film className="w-3.5 h-3.5 text-indigo-400" />
                <span>{isMy ? 'နမူနာ ဖိုင်ဖြင့် စမ်းသပ်မည် (Try Sample)' : 'Use Demo Sample'}</span>
              </button>
            </div>
          </div>
        ) : (
          /* File Preview & Media Player */
          <div className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Media Player */}
              <div className="lg:col-span-7 bg-black rounded-2xl overflow-hidden border border-slate-800 shadow-xl relative aspect-video flex items-center justify-center">
                {selectedFile.type.startsWith('video/') ? (
                  <video
                    ref={videoRef}
                    src={videoPreviewUrl || ''}
                    controls
                    onLoadedMetadata={(e) => {
                      const target = e.currentTarget;
                      if (target.duration && !isNaN(target.duration)) {
                        setVideoDuration(target.duration);
                      }
                    }}
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center p-6 text-center space-y-4 w-full h-full bg-gradient-to-b from-slate-900 to-slate-950">
                    <div className="w-16 h-16 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 flex items-center justify-center animate-pulse">
                      <FileAudio className="w-8 h-8" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-200">{selectedFile.name}</p>
                      <p className="text-xs text-slate-400 mt-1">{isMy ? 'အသံဖိုင် စစ်ဆေးပြီး' : 'Audio Track Loaded'}</p>
                    </div>
                    {videoPreviewUrl && (
                      <audio
                        ref={videoRef as any}
                        src={videoPreviewUrl}
                        controls
                        className="w-full max-w-md mt-2"
                        onLoadedMetadata={(e) => {
                          const target = e.currentTarget;
                          if (target.duration && !isNaN(target.duration)) {
                            setVideoDuration(target.duration);
                          }
                        }}
                      />
                    )}
                  </div>
                )}
              </div>

              {/* Meta Card */}
              <div className="lg:col-span-5 flex flex-col justify-between space-y-4 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-5">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                    {isMy ? 'ဗီဒီယို ဖိုင်အချက်အလက်များ' : 'Video Information'}
                  </h4>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between py-2 border-b border-slate-800/60 text-xs">
                      <span className="text-slate-400">{isMy ? 'ဖိုင်အမည်' : 'File Name'}:</span>
                      <span className="font-semibold text-slate-200 max-w-[180px] truncate" title={selectedFile.name}>
                        {selectedFile.name}
                      </span>
                    </div>

                    <div className="flex items-center justify-between py-2 border-b border-slate-800/60 text-xs">
                      <span className="text-slate-400">{isMy ? 'ဖိုင်အရွယ်အစား' : 'File Size'}:</span>
                      <span className="font-mono text-slate-200 font-medium">
                        {formatFileSize(selectedFile.size)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between py-2 border-b border-slate-800/60 text-xs">
                      <span className="text-slate-400">{isMy ? 'အမျိုးအစား' : 'Format'}:</span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-indigo-300 font-mono text-[11px]">
                        {selectedFile.type || 'video/mp4'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between py-2 border-b border-slate-800/60 text-xs">
                      <span className="text-slate-400">{isMy ? 'ကြာချိန်' : 'Duration'}:</span>
                      <span className="font-mono text-emerald-400 font-semibold">
                        {formatTime(videoDuration)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={handleClear}
                    className="p-2.5 rounded-xl text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 border border-slate-800 hover:border-rose-500/30 transition text-xs flex items-center justify-center"
                    title={isMy ? 'ဖိုင် အသစ်လဲမည်' : 'Remove File'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={onProceedToStep3}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 shadow-md shadow-indigo-600/30 transition transform active:scale-[0.98]"
                  >
                    <span>{isMy ? 'အဆင့် ၃ စာသားထုတ်ယူရန် ဆက်သွားမည်' : 'Proceed to Step 3: Transcribe'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
