import React, { useState } from 'react';
import {
  FileText,
  Download,
  Copy,
  Check,
  Search,
  Sparkles,
  Subtitles,
  Play,
  RotateCcw,
  Languages,
  Clock,
  Globe2,
  Mic,
  Film,
} from 'lucide-react';
import { AppLanguage, TranscriptionResult } from '../types';

interface Step4TranscriptProps {
  result: TranscriptionResult;
  onSeekVideo?: (timeSec: number) => void;
  onStartNew: () => void;
  onProceedToStep5?: () => void;
  onProceedToStep6?: () => void;
  appLang: AppLanguage;
}

type ViewMode = 'burmese' | 'bilingual' | 'original';

export const Step4Transcript: React.FC<Step4TranscriptProps> = ({
  result,
  onSeekVideo,
  onStartNew,
  onProceedToStep5,
  onProceedToStep6,
  appLang,
}) => {
  const [activeTab, setActiveTab] = useState<'interactive' | 'plain' | 'summary'>('interactive');
  const [viewMode, setViewMode] = useState<ViewMode>('burmese');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const isMy = appLang === 'my';

  // Convert MM:SS or HH:MM:SS to seconds
  const parseTimeToSeconds = (timeStr: string): number => {
    if (!timeStr) return 0;
    const parts = timeStr.split(':').map((p) => parseInt(p, 10));
    if (parts.length === 2) {
      return (parts[0] || 0) * 60 + (parts[1] || 0);
    }
    if (parts.length === 3) {
      return (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0);
    }
    return 0;
  };

  const getActiveTextToExport = (mode: ViewMode): string => {
    if (mode === 'burmese') return result.burmeseTranscript || result.plainText;
    if (mode === 'original') return result.originalTranscript || result.plainText;
    return result.bilingualTranscript || result.burmeseTranscript || result.plainText;
  };

  const currentPlainText = getActiveTextToExport(viewMode);

  const handleCopy = () => {
    const textToCopy =
      activeTab === 'summary'
        ? `${result.summary}\n\nအဓိက အချက်များ:\n${result.keyPoints.join('\n')}`
        : currentPlainText;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (content: string, filename: string, mime: string) => {
    // Add UTF-8 BOM so Burmese characters render flawlessly in Windows Notepad and all editors
    const bom = '\uFEFF';
    const blob = new Blob([bom + content], { type: `${mime};charset=utf-8` });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadTxt = (mode: ViewMode = viewMode) => {
    const baseName = result.fileName.replace(/\.[^/.]+$/, '');
    const content = getActiveTextToExport(mode);
    const suffix = mode === 'burmese' ? 'burmese_transcript' : mode === 'bilingual' ? 'bilingual_transcript' : 'original_transcript';
    downloadFile(content, `${baseName}_${suffix}.txt`, 'text/plain');
  };

  const handleDownloadSrt = (isOriginal = false) => {
    const baseName = result.fileName.replace(/\.[^/.]+$/, '');
    const content = isOriginal ? (result.originalSrtContent || result.srtContent) : result.srtContent;
    const suffix = isOriginal ? 'original_subtitles' : 'burmese_subtitles';
    downloadFile(content || result.plainText, `${baseName}_${suffix}.srt`, 'text/plain');
  };

  // Filter segments by search query
  const filteredSegments = searchQuery.trim()
    ? result.segments.filter(
        (seg) =>
          seg.burmeseText?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          seg.originalText?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (seg.speaker && seg.speaker.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : result.segments;

  const wordCount = currentPlainText.split(/\s+/).filter(Boolean).length;
  const charCount = currentPlainText.length;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden backdrop-blur-xl">
      {/* Background glow */}
      <div className="absolute top-0 right-0 -mt-16 -mr-16 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/25">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                {isMy ? 'အဆင့် ၄' : 'Step 4'}
              </span>
              <h2 className="text-xl font-bold text-white">
                {isMy ? 'Transcript စာသားနှင့် TXT ရယူခြင်း' : 'Transcript & TXT Export'}
              </h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              {isMy
                ? 'အချိန် အတိအကျနှင့် မြန်မာဘာသာပြန်ထားသော စာသားကို ဖတ်ရှုပြီး .TXT ဖိုင်အဖြစ် ဒေါင်းလုဒ် ရယူပါ'
                : 'Review transcript with exact timestamps and full Burmese translation'}
            </p>
          </div>
        </div>

        {/* Action Buttons: TXT Download & Copy */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span>{copied ? (isMy ? 'ကော်ပီကူးပြီးပါပြီ!' : 'Copied!') : (isMy ? 'စာသား ကော်ပီကူးမည်' : 'Copy Text')}</span>
          </button>

          {/* Download Burmese TXT */}
          <button
            onClick={() => handleDownloadTxt('burmese')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 shadow-md shadow-emerald-500/20 transition transform active:scale-95"
            title={isMy ? 'အချိန်အတိအကျပါသော မြန်မာဘာသာပြန် .TXT ဖိုင် ဒေါင်းလုဒ်ရယူမည်' : 'Download Burmese transcript TXT with exact timestamps'}
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isMy ? 'မြန်မာဘာသာပြန် .TXT ဒေါင်းလုဒ်' : 'Download Burmese .TXT'}</span>
          </button>

          {/* Download Bilingual TXT */}
          <button
            onClick={() => handleDownloadTxt('bilingual')}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
            title={isMy ? 'မူရင်း နှင့် မြန်မာ နှစ်ဘာသာတွဲ .TXT ဖိုင်' : 'Download Bilingual TXT'}
          >
            <Download className="w-3.5 h-3.5 text-teal-400" />
            <span>{isMy ? 'နှစ်ဘာသာ .TXT' : 'Bilingual .TXT'}</span>
          </button>

          {/* Download Burmese SRT */}
          {result.srtContent && (
            <button
              onClick={() => handleDownloadSrt(false)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
              title={isMy ? 'အချိန်အတိအကျပါ မြန်မာ Subtitle .SRT ဖိုင် ဒေါင်းလုဒ်' : 'Download Burmese Subtitles (.SRT)'}
            >
              <Subtitles className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isMy ? 'မြန်မာ .SRT' : 'Burmese .SRT'}</span>
            </button>
          )}

          {onProceedToStep5 && (
            <button
              onClick={onProceedToStep5}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-fuchsia-600 to-pink-600 hover:from-fuchsia-500 hover:to-pink-500 shadow-md shadow-fuchsia-600/30 transition transform active:scale-95"
            >
              <Mic className="w-3.5 h-3.5 text-fuchsia-200" />
              <span>{isMy ? 'အဆင့် ၅: Voice Clone ➔' : 'Step 5: Voice Clone ➔'}</span>
            </button>
          )}

          {onProceedToStep6 && (
            <button
              onClick={onProceedToStep6}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 shadow-md shadow-rose-600/30 transition transform active:scale-95"
            >
              <Film className="w-3.5 h-3.5 text-rose-200" />
              <span>{isMy ? 'အဆင့် ၆: Video Dubbing ➔' : 'Step 6: Video Dubbing ➔'}</span>
            </button>
          )}

          <button
            onClick={onStartNew}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 transition"
            title={isMy ? 'အသစ်စတင်မည်' : 'Start New'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isMy ? 'အသစ်လုပ်မည်' : 'New'}</span>
          </button>
        </div>
      </div>

      {/* Meta Bar & Mode Switcher */}
      <div className="mt-4 flex flex-col md:flex-row md:items-center justify-between gap-3 p-3.5 bg-slate-950/70 border border-slate-800/80 rounded-xl text-xs text-slate-400">
        {/* Info stats */}
        <div className="flex flex-wrap items-center gap-3">
          <span className="flex items-center gap-1.5 text-slate-300 font-medium">
            <span className="text-slate-500">{isMy ? 'ဖိုင်:' : 'File:'}</span>
            <span className="text-emerald-400 font-mono truncate max-w-[180px]">{result.fileName}</span>
          </span>
          <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
            {isMy ? 'မူရင်းဘာသာ:' : 'Detected:'} <strong className="text-white">{result.detectedLanguage}</strong>
          </span>
          <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-medium">
            {isMy ? 'ဘာသာပြန်:' : 'Translated to:'} <strong>မြန်မာဘာသာ (Burmese)</strong>
          </span>
        </div>

        {/* View mode toggle: Burmese / Bilingual / Original */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setViewMode('burmese')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              viewMode === 'burmese'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isMy ? 'မြန်မာဘာသာပြန်' : 'Burmese'}
          </button>
          <button
            onClick={() => setViewMode('bilingual')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              viewMode === 'bilingual'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isMy ? 'နှစ်ဘာသာတွဲ' : 'Bilingual'}
          </button>
          <button
            onClick={() => setViewMode('original')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              viewMode === 'original'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isMy ? 'မူရင်းဘာသာ' : 'Original'}
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('interactive')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
              activeTab === 'interactive'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{isMy ? 'အချိန်မှတ်သားချက်ပါ စာသားလိုင်းများ' : 'Interactive Timestamp View'}</span>
            {result.segments.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-slate-300">
                {result.segments.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('plain')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
              activeTab === 'plain'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{isMy ? 'TXT စာသားစစ်စစ် (Plain Text View)' : 'Plain Text (.TXT)'}</span>
          </button>

          {result.summary && (
            <button
              onClick={() => setActiveTab('summary')}
              className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'summary'
                  ? 'border-emerald-400 text-emerald-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{isMy ? 'မြန်မာ အနှစ်ချုပ် (Summary)' : 'Burmese Summary'}</span>
            </button>
          )}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-56 pb-2 sm:pb-0">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isMy ? 'စာသားအတွင်း ရှာရန်...' : 'Search transcript...'}
            className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-700/80 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* Tab Content */}
      <div className="mt-4">
        {/* Tab 1: Interactive Segments with Exact Timestamps */}
        {activeTab === 'interactive' && (
          <div className="space-y-3 max-h-[520px] overflow-y-auto pr-2">
            {filteredSegments.length > 0 ? (
              filteredSegments.map((segment, idx) => {
                const startSec = parseTimeToSeconds(segment.start);
                const endSec = parseTimeToSeconds(segment.end);
                const duration = Math.max(1, endSec - startSec);

                return (
                  <div
                    key={idx}
                    className="group p-4 rounded-xl bg-slate-950/50 hover:bg-slate-950/80 border border-slate-800/80 hover:border-emerald-500/40 transition duration-150 flex flex-col sm:flex-row sm:items-start gap-3.5"
                  >
                    {/* Exact Timestamp Badge: [00:02 - 00:07] with seek button */}
                    <button
                      onClick={() => onSeekVideo?.(startSec)}
                      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-mono transition shrink-0 self-start group/btn"
                      title={isMy ? `ဗီဒီယိုကို ${segment.start} သို့ ရွှေ့မည်` : `Jump to ${segment.start}`}
                    >
                      <Play className="w-3 h-3 fill-current group-hover/btn:scale-110 transition" />
                      <span className="font-bold tracking-tight">
                        {segment.start} - {segment.end}
                      </span>
                      <span className="text-[10px] text-emerald-500/70 border-l border-emerald-500/20 pl-1.5">
                        {duration}s
                      </span>
                    </button>

                    <div className="flex-1 space-y-1.5">
                      {segment.speaker && (
                        <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wide mr-2 block sm:inline">
                          {segment.speaker}:
                        </span>
                      )}

                      {/* Display based on viewMode */}
                      {viewMode === 'burmese' && (
                        <p className="text-sm text-slate-100 leading-relaxed font-normal">
                          {segment.burmeseText || segment.text}
                        </p>
                      )}

                      {viewMode === 'original' && (
                        <p className="text-sm text-slate-300 leading-relaxed font-normal">
                          {segment.originalText || segment.text}
                        </p>
                      )}

                      {viewMode === 'bilingual' && (
                        <div className="space-y-1.5">
                          <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80">
                            <span className="text-[10px] font-bold text-emerald-400 uppercase block mb-0.5">
                              {isMy ? '🇲🇲 မြန်မာဘာသာပြန်:' : 'Burmese:'}
                            </span>
                            <p className="text-sm text-slate-100 leading-relaxed">
                              {segment.burmeseText || segment.text}
                            </p>
                          </div>
                          {segment.originalText && segment.originalText !== segment.burmeseText && (
                            <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/40">
                              <span className="text-[10px] font-bold text-slate-400 uppercase block mb-0.5">
                                {isMy ? '🌐 မူရင်းဘာသာ:' : 'Original:'}
                              </span>
                              <p className="text-xs text-slate-300 leading-relaxed font-mono">
                                {segment.originalText}
                              </p>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center text-slate-500 text-xs">
                {searchQuery ? (isMy ? 'ရှာဖွေမှုနှင့် ကိုက်ညီသော စာသားမရှိပါ' : 'No matching segments found') : (
                  <p className="font-mono text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {currentPlainText}
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Plain Text */}
        {activeTab === 'plain' && (
          <div className="relative">
            <textarea
              readOnly
              value={currentPlainText}
              rows={16}
              className="w-full p-4 rounded-xl bg-slate-950/90 border border-slate-800 font-sans text-sm text-slate-200 leading-relaxed focus:outline-none resize-none select-all"
            />
            <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
              <div className="flex items-center gap-4">
                <span>
                  {isMy ? 'စာလုံးရေ:' : 'Words:'} <strong className="text-white font-mono">{wordCount}</strong>
                </span>
                <span>
                  {isMy ? 'အက္ခရာ:' : 'Characters:'} <strong className="text-white font-mono">{charCount}</strong>
                </span>
                <span className="text-emerald-400">
                  {isMy ? 'အချိန်အတိအကျ [MM:SS] ပါဝင်ပြီးဖြစ်သည်' : 'Exact timestamps included'}
                </span>
              </div>
              <button
                onClick={() => handleDownloadTxt(viewMode)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-medium transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isMy ? 'ဤစာသားကို .TXT အဖြစ် ဒေါင်းလုဒ်လုပ်မည်' : 'Download as .TXT'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Summary */}
        {activeTab === 'summary' && (
          <div className="space-y-4 p-5 rounded-xl bg-slate-950/60 border border-slate-800">
            {result.summary && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-2">
                  {isMy ? 'ဗီဒီယို၏ အဓိကဆိုလိုရင်း အနှစ်ချုပ် (Burmese Summary)' : 'Executive Summary'}
                </h4>
                <p className="text-sm text-slate-200 leading-relaxed">{result.summary}</p>
              </div>
            )}

            {result.keyPoints && result.keyPoints.length > 0 && (
              <div className="pt-3 border-t border-slate-800/80">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-2">
                  {isMy ? 'အဓိက အချက်များ' : 'Key Takeaways'}
                </h4>
                <ul className="space-y-2">
                  {result.keyPoints.map((point, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
