import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Film,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Sliders,
  Download,
  RotateCcw,
  Sparkles,
  Subtitles,
  CheckCircle2,
  Layers,
  ArrowRight,
  Clock,
  AudioWaveform as Waveform,
  Check,
  FastForward,
  Rewind,
  AlertCircle,
  AlertTriangle,
  Mic,
  Zap,
  Upload,
  RefreshCw,
  ExternalLink,
  SlidersHorizontal,
} from 'lucide-react';
import {
  AppLanguage,
  TranscriptionResult,
  VoiceCloneAudioResult,
  TranscriptSegment,
} from '../types';
import {
  parseTimestampToSeconds,
  audioBufferToWavBlob,
  assembleTimelineAudio,
  buildCompleteTimeAlignedTrack,
  SegmentAudioItem,
} from '../utils/audioSyncHelper';

interface Step6DubbingProps {
  videoPreviewUrl: string | null;
  videoFileName: string;
  voiceAudioResult: VoiceCloneAudioResult | null;
  setVoiceAudioResult?: (res: VoiceCloneAudioResult | null) => void;
  transcriptionResult: TranscriptionResult;
  referenceAudioBase64?: string;
  referenceAudioName?: string;
  apiKey?: string;
  appLang: AppLanguage;
  onStartNew: () => void;
  onGoToStep5?: () => void;
  onSelectNewVideo?: (file: File) => void;
}

export const Step6Dubbing: React.FC<Step6DubbingProps> = ({
  videoPreviewUrl,
  videoFileName,
  voiceAudioResult,
  setVoiceAudioResult,
  transcriptionResult,
  referenceAudioBase64,
  referenceAudioName,
  apiKey,
  appLang,
  onStartNew,
  onGoToStep5,
  onSelectNewVideo,
}) => {
  const isMy = appLang === 'my';

  // Video & Audio Element Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const dubbedAudioRef = useRef<HTMLAudioElement | null>(null);

  // Playback State
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);

  // Volume & Mixing State
  const [originalVolume, setOriginalVolume] = useState<number>(0); // 0 = Pure Burmese Dubbing
  const [dubbedVolume, setDubbedVolume] = useState<number>(1.0);  // 100% Burmese voice
  const [voicePlaybackSpeed, setVoicePlaybackSpeed] = useState<number>(1.0); // Tempo

  // Exact Lip-Sync & Offset Alignment State
  const [syncOffsetSec, setSyncOffsetSec] = useState<number>(0.0);

  // Subtitle Overlay State
  const [showSubtitles, setShowSubtitles] = useState<boolean>(true);
  const [activeSubtitle, setActiveSubtitle] = useState<string>('');
  const [activeSegmentIndex, setActiveSegmentIndex] = useState<number>(-1);

  // Segment Nudges (individual segment start time adjustments in seconds)
  const [segmentNudges, setSegmentNudges] = useState<Record<number, number>>({});

  // Sync Mode: 'time_aligned' (Every dialogue matched to segment timestamp) vs 'continuous'
  const [syncMode, setSyncMode] = useState<'time_aligned' | 'continuous'>('time_aligned');

  // Time-Aligned Audio State
  const [isBuildingAlignedTrack, setIsBuildingAlignedTrack] = useState<boolean>(false);
  const [alignedProgressMsg, setAlignedProgressMsg] = useState<string>('');
  const [alignedTrackResult, setAlignedTrackResult] = useState<VoiceCloneAudioResult | null>(null);
  const [selectedVoice, setSelectedVoice] = useState<string>(
    voiceAudioResult?.voiceName || '🗣️ ခိုင်ခိုင်'
  );

  // Video Export State
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportedVideoUrl, setExportedVideoUrl] = useState<string | null>(null);

  // Active audio URL and alignment status
  const isCurrentlyAligned = Boolean(
    alignedTrackResult?.isTimeAligned || voiceAudioResult?.isTimeAligned
  );
  const activeAudioUrl = alignedTrackResult?.audioUrl || voiceAudioResult?.audioUrl || null;

  // Calculate parsed segments with seconds
  const parsedSegments = useMemo(() => {
    return (transcriptionResult.segments || []).map((seg, idx) => {
      const startBase = parseTimestampToSeconds(seg.start);
      const endBase = parseTimestampToSeconds(seg.end);
      const userNudge = segmentNudges[idx] || 0;
      return {
        ...seg,
        index: idx,
        startSec: Math.max(0, startBase + userNudge),
        endSec: Math.max(startBase + 0.5, endBase + userNudge),
      };
    });
  }, [transcriptionResult.segments, segmentNudges]);

  // Sync Video & Audio volumes
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = originalVolume;
    }
  }, [originalVolume]);

  useEffect(() => {
    if (dubbedAudioRef.current) {
      dubbedAudioRef.current.volume = Math.min(1.0, dubbedVolume);
      dubbedAudioRef.current.playbackRate = voicePlaybackSpeed;
    }
  }, [dubbedVolume, voicePlaybackSpeed]);

  // Master Play/Pause control
  const handleTogglePlay = async () => {
    const video = videoRef.current;
    const audio = dubbedAudioRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
      if (audio) audio.pause();
      setIsPlaying(false);
    } else {
      if (audio && activeAudioUrl) {
        // In time_aligned mode, the audio track is built on the exact video timeline!
        const targetAudioTime =
          syncMode === 'time_aligned'
            ? Math.max(0, video.currentTime + syncOffsetSec)
            : Math.max(0, video.currentTime - syncOffsetSec);

        if (targetAudioTime < (audio.duration || Infinity)) {
          audio.currentTime = targetAudioTime;
          audio.playbackRate = voicePlaybackSpeed;
          audio.play().catch(() => {});
        }
      }
      try {
        await video.play();
        setIsPlaying(true);
      } catch (e) {
        console.warn('Playback error:', e);
      }
    }
  };

  // Time update listener
  const handleTimeUpdate = () => {
    const video = videoRef.current;
    const audio = dubbedAudioRef.current;
    if (!video) return;

    const time = video.currentTime;
    setCurrentTime(time);

    // Keep audio synced if drifting more than 0.15s
    if (audio && !audio.paused && !video.paused && activeAudioUrl) {
      const expectedAudioTime =
        syncMode === 'time_aligned'
          ? Math.max(0, time + syncOffsetSec)
          : Math.max(0, time - syncOffsetSec);

      if (Math.abs(audio.currentTime - expectedAudioTime) > 0.18) {
        audio.currentTime = expectedAudioTime;
      }
    }

    // Find active segment for subtitle display
    const foundIdx = parsedSegments.findIndex(
      (seg) => time >= seg.startSec && time <= seg.endSec
    );

    if (foundIdx !== -1) {
      const seg = parsedSegments[foundIdx];
      setActiveSubtitle(seg.burmeseText || seg.text);
      setActiveSegmentIndex(foundIdx);
    } else {
      setActiveSubtitle('');
      setActiveSegmentIndex(-1);
    }
  };

  // Seeking on scrub bar
  const handleSeek = (newTime: number) => {
    const video = videoRef.current;
    const audio = dubbedAudioRef.current;
    if (!video) return;

    video.currentTime = newTime;
    setCurrentTime(newTime);

    if (audio && activeAudioUrl) {
      const targetAudioTime =
        syncMode === 'time_aligned'
          ? Math.max(0, newTime + syncOffsetSec)
          : Math.max(0, newTime - syncOffsetSec);
      audio.currentTime = targetAudioTime;
    }
  };

  // Jump to specific segment and play immediately
  const handleJumpToSegment = (seg: { startSec: number }) => {
    const video = videoRef.current;
    const audio = dubbedAudioRef.current;
    if (!video) return;

    video.currentTime = seg.startSec;
    setCurrentTime(seg.startSec);

    if (audio && activeAudioUrl) {
      audio.currentTime = Math.max(0, seg.startSec + syncOffsetSec);
      audio.playbackRate = voicePlaybackSpeed;
      audio.play().catch(() => {});
    }

    video.play().catch(() => {});
    setIsPlaying(true);
  };

  // Adjust global offset
  const handleOffsetChange = (offset: number) => {
    const cleanOffset = parseFloat(offset.toFixed(2));
    setSyncOffsetSec(cleanOffset);
    const audio = dubbedAudioRef.current;
    const video = videoRef.current;
    if (audio && video && activeAudioUrl) {
      const targetTime =
        syncMode === 'time_aligned'
          ? Math.max(0, video.currentTime + cleanOffset)
          : Math.max(0, video.currentTime - cleanOffset);
      audio.currentTime = targetTime;
    }
  };

  // Adjust per-segment nudge (+/- 0.1s)
  const handleNudgeSegment = (idx: number, delta: number) => {
    setSegmentNudges((prev) => ({
      ...prev,
      [idx]: parseFloat(((prev[idx] || 0) + delta).toFixed(2)),
    }));
  };

  // Build Time-Aligned Audio Track (100% in-sync with video timestamps)
  const handleBuildTimeAlignedTrack = async (customSpeed?: number) => {
    setIsBuildingAlignedTrack(true);
    setAlignedProgressMsg(
      isMy
        ? 'စာတန်းထိုး အပိုင်းလိုက် အသံများကို Gemini TTS ဖြင့် ထုတ်ယူနေပါသည်...'
        : 'Synthesizing speech for each subtitle segment...'
    );

    try {
      const speedToUse = customSpeed !== undefined ? customSpeed : voicePlaybackSpeed;
      const alignedResult = await buildCompleteTimeAlignedTrack({
        segments: transcriptionResult.segments,
        presetVoice: selectedVoice,
        apiKey,
        totalVideoDuration: duration || 10,
        speechSpeed: speedToUse,
        onProgress: (m) => setAlignedProgressMsg(m),
      });

      setAlignedTrackResult(alignedResult);
      if (setVoiceAudioResult) {
        setVoiceAudioResult(alignedResult);
      }
      setSyncMode('time_aligned');
      setSyncOffsetSec(0.0); // Reset offset because it is now sample-accurately aligned!

      // Update audio player
      if (dubbedAudioRef.current) {
        dubbedAudioRef.current.src = alignedResult.audioUrl;
        dubbedAudioRef.current.currentTime = videoRef.current?.currentTime || 0;
      }
    } catch (err: any) {
      console.error('Time aligned track error:', err);
      alert(err.message || (isMy ? 'စာတန်းထိုး အသံပေါင်းစပ်မှု မအောင်မြင်ပါ' : 'Failed to align audio'));
    } finally {
      setIsBuildingAlignedTrack(false);
      setAlignedProgressMsg('');
    }
  };

  // Export Dubbed Video using Client Canvas/MediaRecorder
  const handleExportDubbedVideo = async () => {
    const video = videoRef.current;
    const audio = dubbedAudioRef.current;
    if (!video) return;

    setIsExporting(true);
    setExportProgress(0);

    try {
      const width = video.videoWidth || 1280;
      const height = video.videoHeight || 720;
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas not supported');

      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const dest = audioCtx.createMediaStreamDestination();

      // Video audio source
      try {
        const videoSourceNode = audioCtx.createMediaElementSource(video);
        const videoGain = audioCtx.createGain();
        videoGain.gain.value = originalVolume;
        videoSourceNode.connect(videoGain);
        videoGain.connect(dest);
      } catch (e) {
        console.warn('Video audio source notice:', e);
      }

      // Dubbed audio source
      if (audio && activeAudioUrl) {
        try {
          const dubbedSourceNode = audioCtx.createMediaElementSource(audio);
          const dubbedGain = audioCtx.createGain();
          dubbedGain.gain.value = dubbedVolume;
          dubbedSourceNode.connect(dubbedGain);
          dubbedGain.connect(dest);
        } catch (e) {
          console.warn('Dubbed audio source notice:', e);
        }
      }

      const canvasStream = canvas.captureStream(30);
      const combinedTracks = [
        ...canvasStream.getVideoTracks(),
        ...dest.stream.getAudioTracks(),
      ];
      const combinedStream = new MediaStream(combinedTracks);

      const mimeType = MediaRecorder.isTypeSupported('video/mp4')
        ? 'video/mp4'
        : 'video/webm;codecs=vp9,opus';

      const recorder = new MediaRecorder(combinedStream, { mimeType });
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      const totalDuration = video.duration || 10;

      recorder.onstop = () => {
        const finalBlob = new Blob(chunks, { type: mimeType });
        const url = URL.createObjectURL(finalBlob);
        setExportedVideoUrl(url);
        setIsExporting(false);
        setExportProgress(100);
      };

      // Rewind and start
      video.currentTime = 0;
      if (audio) {
        audio.currentTime = Math.max(0, syncOffsetSec);
      }

      recorder.start(100);
      await Promise.all([video.play(), audio ? audio.play() : Promise.resolve()]);

      const renderInterval = setInterval(() => {
        if (video.ended || video.currentTime >= totalDuration) {
          clearInterval(renderInterval);
          if (recorder.state === 'recording') recorder.stop();
          return;
        }

        // Draw video frame
        ctx.drawImage(video, 0, 0, width, height);

        // Draw burned-in Burmese subtitles if enabled
        if (showSubtitles && activeSubtitle) {
          ctx.font = 'bold 28px "Padauk", "Noto Sans Myanmar", sans-serif';
          ctx.textAlign = 'center';
          const textMetrics = ctx.measureText(activeSubtitle);
          const bgPadding = 16;
          const boxWidth = textMetrics.width + bgPadding * 2;
          const boxHeight = 46;

          // Semi-transparent rounded box
          ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
          ctx.fillRect(width / 2 - boxWidth / 2, height - 75 - boxHeight, boxWidth, boxHeight);

          // Crisp white text with shadow
          ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
          ctx.shadowBlur = 4;
          ctx.fillStyle = '#FFFFFF';
          ctx.fillText(activeSubtitle, width / 2, height - 85);
          ctx.shadowBlur = 0;
        }

        const pct = Math.min(99, Math.round((video.currentTime / totalDuration) * 100));
        setExportProgress(pct);
      }, 1000 / 30);
    } catch (err: any) {
      console.error('Export error:', err);
      setIsExporting(false);
    }
  };

  const formatTime = (secs: number): string => {
    if (!secs || isNaN(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden backdrop-blur-xl">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-0 -mt-16 -mr-16 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-rose-500 via-pink-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-rose-500/25">
            <Film className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-400 bg-rose-500/10 px-2.5 py-0.5 rounded-full border border-rose-500/20">
                {isMy ? 'အဆင့် ၆' : 'Step 6'}
              </span>
              <h2 className="text-xl font-bold text-white">
                {isMy ? 'ဗီဒီယို၊ မြန်မာအသံနှင့် စာတန်းထိုး ကွက်တိကိုက်ညှိစနစ်' : 'Video, Subtitles & Audio Exact Sync Studio'}
              </h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              {isMy
                ? 'ဗီဒီယို စာတန်းထိုးစကားပြောချိန် [MM:SS] အတိအကျအတိုင်း မြန်မာအသံကို ကွက်တိကျစေရန် စီစဉ်ပါ'
                : 'Synchronize Burmese voice and subtitles with exact dialogue cues on the video timeline'}
            </p>
          </div>
        </div>

        {/* Action Controls: Export Video & Start New */}
        <div className="flex flex-wrap items-center gap-2">
          {exportedVideoUrl ? (
            <a
              href={exportedVideoUrl}
              download={`dubbed_${videoFileName.replace(/\.[^/.]+$/, '')}.mp4`}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 shadow-md shadow-emerald-500/20 transition transform active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>{isMy ? 'Dubbed Video ဒေါင်းလုဒ် (.MP4)' : 'Download Dubbed Video'}</span>
            </a>
          ) : (
            <button
              onClick={handleExportDubbedVideo}
              disabled={isExporting || !videoPreviewUrl}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-400 hover:to-pink-500 shadow-md shadow-rose-500/25 transition transform active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              {isExporting ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin" />
                  <span>{isMy ? `ပေါင်းစပ်နေသည် (${exportProgress}%)` : `Exporting (${exportProgress}%)`}</span>
                </>
              ) : (
                <>
                  <Film className="w-4 h-4" />
                  <span>{isMy ? 'Dubbed Video ထုတ်ယူမည် (.MP4)' : 'Export Dubbed Video'}</span>
                </>
              )}
            </button>
          )}

          {activeAudioUrl && (
            <a
              href={activeAudioUrl}
              download={`time_aligned_burmese_audio_${Date.now()}.wav`}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
              title={isMy ? 'ကွက်တိကိုက် မြန်မာအသံဖိုင် သီးသန့်ဒေါင်းလုဒ်' : 'Download Aligned Audio Track'}
            >
              <Download className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">{isMy ? 'အသံဖိုင် (.WAV)' : 'Audio (.WAV)'}</span>
            </a>
          )}

          <button
            onClick={onStartNew}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 border border-slate-800 transition"
            title={isMy ? 'အသစ်ပြန်လည်စတင်မည်' : 'Start New Project'}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ALIGNMENT STATUS & ACTION BANNER */}
      {!isCurrentlyAligned ? (
        <div className="mt-4 p-5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-purple-500/15 border-2 border-amber-500/40 shadow-xl shadow-amber-950/20 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 mt-0.5 border border-amber-500/30 shadow-md">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                  {isMy ? '⚠️ အသံဖိုင် အချိန်ကိုက် ညှိရန် လိုအပ်နေပါသည်' : '⚠️ Audio Alignment Required'}
                </span>
                <span className="text-[11px] text-slate-400">
                  ({parsedSegments.length} Segments Detected)
                </span>
              </div>
              <h3 className="text-sm font-bold text-white">
                {isMy
                  ? 'အသံမြန်နေခြင်းနှင့် စာတန်းထိုး မညီမညာဖြစ်ခြင်းကို ဖြေရှင်းရန်'
                  : 'Fix Audio Pacing & Misalignment with Video Subtitles'}
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                {isMy
                  ? 'လက်ရှိအသံသည် စကားလုံးများ ဆက်တိုက်ထွက်နေသဖြင့် အသံမြန်နေသလို ဖြစ်နေပါသည်။ ဥပမာ: [00:00 - 00:06] တွင် "မင်္ဂလာပါ" ပြောပြီး၊ [00:06 - 00:10] တွင်မှ "ဘာတွေလုပ်နေလဲ" စသည်ဖြင့် စကားပြောတစ်ခုချင်းစီ၏ အချိန်တိုင်းတွင် အတိအကျ ကွက်တိကျစေရန် ချက်ချင်း ကွက်တိညှိပါ:'
                  : 'Current voice is continuous and rushed. Click below to lock each sentence to its exact cue timing (e.g. 00:00 -> 00:06 "မင်္ဂလာပါ", then 00:06 -> 00:10 "ဘာတွေလုပ်နေလဲ"): '}
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="w-full sm:w-auto bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
            >
              <option value="🗣️ ခိုင်ခိုင်">🗣️ ခိုင်ခိုင် (Female)</option>
              <option value="🗣️ ကျော်ကျော်">🗣️ ကျော်ကျော် (Male)</option>
              <option value="🗣️ မျိုးသန့်">🗣️ မျိုးသန့် (Narrator)</option>
              <option value="🗣️ သဇင်">🗣️ သဇင် (Sweet)</option>
              <option value="🎙️ ကိုကို (Host)">🎙️ ကိုကို (Host)</option>
            </select>

            <button
              type="button"
              onClick={() => handleBuildTimeAlignedTrack()}
              disabled={isBuildingAlignedTrack}
              className="w-full sm:w-auto px-5 py-3 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-emerald-400 to-teal-400 hover:from-amber-300 hover:to-teal-300 shadow-lg shadow-amber-500/25 transition transform active:scale-95 disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
            >
              {isBuildingAlignedTrack ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-slate-950" />
                  <span>{alignedProgressMsg || (isMy ? 'ကွက်တိညှိနေသည်...' : 'Aligning...')}</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-slate-950 fill-current" />
                  <span>{isMy ? '⚡ စာတန်းထိုး အချိန်အတိုင်း ကွက်တိညှိမည်' : '⚡ Fix Alignment to Video Timestamps'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-4 p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-slate-900 border border-emerald-500/30 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg shadow-emerald-950/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-300">
                  {isMy ? '✅ စာတန်းထိုးနှင့် မြန်မာအသံ အချိန် ကွက်တိကိုက်ညီနေပါသည်' : '✅ 100% Time-Aligned Track Active'}
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/40 text-[10px] font-mono">
                  {parsedSegments.length} Segments Locked
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                {isMy
                  ? 'ဥပမာ: 00:00 - 00:06 တွင် ပထမစာကြောင်း၊ 00:06 - 00:10 တွင် ဒုတိယစာကြောင်း စသည်ဖြင့် အချိန်အတိအကျ အသံထွက်ပေါ်နေပါပြီ။'
                  : 'Dialogue segments play at their exact cue timestamps with silence gaps during pauses.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
            >
              <option value="🗣️ ခိုင်ခိုင်">🗣️ ခိုင်ခိုင် (Female)</option>
              <option value="🗣️ ကျော်ကျော်">🗣️ ကျော်ကျော် (Male)</option>
              <option value="🗣️ မျိုးသန့်">🗣️ မျိုးသန့် (Narrator)</option>
              <option value="🗣️ သဇင်">🗣️ သဇင် (Sweet)</option>
              <option value="🎙️ ကိုကို (Host)">🎙️ ကိုကို (Host)</option>
            </select>

            <button
              type="button"
              onClick={() => handleBuildTimeAlignedTrack()}
              disabled={isBuildingAlignedTrack}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-1.5"
              title={isMy ? 'အသံ အသစ်ပြန်ထုတ်မည်' : 'Re-generate aligned track'}
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isBuildingAlignedTrack ? 'animate-spin' : ''}`} />
              <span>{isMy ? 'ပြန်လည်ချိန်ညှိမည်' : 'Re-align Track'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Dubbing Workspace */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Synchronized Video Player & Timeline */}
        <div className="lg:col-span-8 space-y-4">
          {/* Video Screen Container */}
          <div className="relative bg-black rounded-2xl overflow-hidden border border-slate-800 shadow-2xl aspect-video flex items-center justify-center group">
            {videoPreviewUrl ? (
              <video
                ref={videoRef}
                src={videoPreviewUrl}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
                onEnded={() => setIsPlaying(false)}
                className="w-full h-full object-contain"
                playsInline
              />
            ) : (
              <div className="text-center p-8 space-y-3">
                <Film className="w-12 h-12 text-slate-600 mx-auto" />
                <p className="text-slate-400 text-sm">
                  {isMy ? 'ဗီဒီယိုဖိုင် မရှိသေးပါ' : 'No video uploaded'}
                </p>
                {onSelectNewVideo && (
                  <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-white border border-slate-700 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{isMy ? 'ဗီဒီယို ဖိုင်တင်မည်' : 'Upload Video'}</span>
                    <input
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) onSelectNewVideo(file);
                      }}
                    />
                  </label>
                )}
              </div>
            )}

            {/* Hidden Audio Element for the Synchronized Dubbed Burmese Voice */}
            {activeAudioUrl && (
              <audio
                ref={dubbedAudioRef}
                src={activeAudioUrl}
                preload="auto"
                className="hidden"
              />
            )}

            {/* Live Burmese Subtitle Overlay on Video Screen */}
            {showSubtitles && activeSubtitle && (
              <div className="absolute bottom-6 left-4 right-4 text-center pointer-events-none transition-all duration-150 animate-in fade-in">
                <span className="inline-block px-5 py-2.5 rounded-xl bg-black/90 text-white font-semibold text-sm sm:text-base border border-white/15 shadow-2xl backdrop-blur-md max-w-xl leading-relaxed">
                  {activeSubtitle}
                </span>
              </div>
            )}

            {/* Play/Pause Large Center Overlay Button */}
            {videoPreviewUrl && (
              <button
                onClick={handleTogglePlay}
                className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-rose-600/90 hover:bg-rose-500 text-white flex items-center justify-center shadow-2xl shadow-rose-600/40 opacity-0 group-hover:opacity-100 transition transform hover:scale-105 active:scale-95"
              >
                {isPlaying ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
              </button>
            )}
          </div>

          {/* Video Scrub Timeline & Controls */}
          <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800/80 flex items-center gap-3">
            <button
              onClick={handleTogglePlay}
              className="w-9 h-9 rounded-lg bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-md shadow-rose-600/20 shrink-0 transition cursor-pointer"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>

            <div className="flex-1 space-y-1">
              <input
                type="range"
                min={0}
                max={duration || 100}
                value={currentTime}
                step={0.1}
                onChange={(e) => handleSeek(parseFloat(e.target.value))}
                className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[11px] font-mono text-slate-400">
                <span className="text-rose-400 font-semibold">{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Subtitle Toggle Button */}
            <button
              onClick={() => setShowSubtitles(!showSubtitles)}
              className={`p-2 rounded-lg text-xs font-medium border transition cursor-pointer ${
                showSubtitles
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                  : 'bg-slate-900 text-slate-400 border-slate-800'
              }`}
              title={isMy ? 'စာတန်းထိုး ဖွင့်/ပိတ်' : 'Toggle Subtitles'}
            >
              <Subtitles className="w-4 h-4" />
            </button>
          </div>

          {/* Interactive Dialogue Segments Cue List ("ကွက်တိ အသံအနေထား စစ်ဆေးရန်") */}
          <div className="bg-slate-950/60 rounded-xl border border-slate-800/80 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-rose-400" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                  {isMy ? 'စာတန်းထိုး စကားပြောချိန် မှတ်သားချက်များ (Cue Points)' : 'Dialogue Cue Points'}
                </h4>
              </div>
              <span className="text-[11px] text-slate-400">
                {parsedSegments.length} {isMy ? 'ပိုဒ်' : 'segments'}
              </span>
            </div>

            <p className="text-[11px] text-slate-400">
              {isMy
                ? 'အောက်ပါ အချိန်မှတ်သားချက်ကို နှိပ်၍ အသံနှင့် စာတန်းထိုး ကွက်တိကျမကျ စမ်းသပ်နားဆင်ပါ။ လိုအပ်ပါက +/- ခလုတ်ဖြင့် စက္ကန့်ပိုင်း ချိန်ညှိနိုင်ပါသည်။'
                : 'Click any cue to audition dialogue synchronization. Fine-tune with +/- buttons if needed.'}
            </p>

            <div className="max-h-64 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              {parsedSegments.map((seg, idx) => {
                const isActive = activeSegmentIndex === idx;
                const nudgeVal = segmentNudges[idx] || 0;

                return (
                  <div
                    key={idx}
                    className={`p-3 rounded-lg border text-xs transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      isActive
                        ? 'bg-rose-500/15 border-rose-500/70 shadow-md ring-1 ring-rose-500/40'
                        : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/60 hover:border-slate-700'
                    }`}
                  >
                    <div
                      onClick={() => handleJumpToSegment(seg)}
                      className="min-w-0 flex-1 space-y-1 cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                          {seg.start} - {seg.end}
                        </span>
                        {seg.speaker && (
                          <span className="text-[10px] text-slate-400">{seg.speaker}</span>
                        )}
                        {isActive ? (
                          <span className="text-[9px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            {isMy ? 'ယခုပြောနေသည်' : 'Speaking Now'}
                          </span>
                        ) : (
                          <span className="text-[9px] text-slate-500 font-mono">
                            {seg.startSec.toFixed(1)}s - {seg.endSec.toFixed(1)}s
                          </span>
                        )}
                      </div>
                      <p className="text-slate-200 font-medium leading-relaxed">
                        {seg.burmeseText || seg.text}
                      </p>
                    </div>

                    {/* Per-segment Fine Nudge Controls */}
                    <div className="flex items-center gap-1 shrink-0 self-end sm:self-center">
                      <button
                        type="button"
                        onClick={() => handleNudgeSegment(idx, -0.1)}
                        className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-mono border border-slate-700"
                        title={isMy ? '၀.၁ စက္ကန့် စောပြောမည်' : 'Speak 0.1s earlier'}
                      >
                        -0.1s
                      </button>
                      <span className="font-mono text-[10px] text-slate-400 min-w-[32px] text-center">
                        {nudgeVal >= 0 ? `+${nudgeVal.toFixed(1)}` : nudgeVal.toFixed(1)}s
                      </span>
                      <button
                        type="button"
                        onClick={() => handleNudgeSegment(idx, +0.1)}
                        className="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-mono border border-slate-700"
                        title={isMy ? '၀.၁ စက္ကန့် နောက်ကျပြောမည်' : 'Speak 0.1s later'}
                      >
                        +0.1s
                      </button>
                      <button
                        type="button"
                        onClick={() => handleJumpToSegment(seg)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 text-white text-[11px] font-bold rounded-lg bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 shadow transition ml-1 cursor-pointer"
                        title={isMy ? `${seg.start} မှ စမ်းဖွင့်မည်` : `Play from ${seg.start}`}
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>{seg.start}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Audio Mixing & Exact Synchronization Controls */}
        <div className="lg:col-span-4 space-y-4">
          {/* Synchronized Track Info Card */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-white uppercase tracking-wider">
              <span className="flex items-center gap-1.5">
                <Mic className="w-4 h-4 text-rose-400" />
                <span>{isMy ? 'မြန်မာအသံဖိုင် အခြေအနေ' : 'Audio Track Status'}</span>
              </span>
              {isCurrentlyAligned ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  {isMy ? '✅ စာတန်းထိုး အချိန်ကိုက်' : 'Time-Aligned Active'}
                </span>
              ) : voiceAudioResult ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  {isMy ? '⚠️ ချိန်ညှိရန် လိုအပ် (Continuous)' : 'Unaligned Continuous'}
                </span>
              ) : (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
                  {isMy ? 'မရှိသေးပါ' : 'None'}
                </span>
              )}
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-400">{isMy ? 'အသံအမျိုးအစား:' : 'Voice:'}</span>
                  <span className="font-semibold text-rose-300 truncate max-w-[150px]">
                    {alignedTrackResult?.voiceName || voiceAudioResult?.voiceName || selectedVoice}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="text-slate-400">{isMy ? 'ကိုက်ညီမှု စနစ်:' : 'Sync Mode:'}</span>
                  <span className="font-mono text-emerald-400 text-[11px]">
                    {isCurrentlyAligned
                      ? (isMy ? 'Timeline Aligned (အချိန်ကိုက်)' : 'Timeline Aligned')
                      : (isMy ? 'Continuous (တစ်ဆက်တည်း)' : 'Continuous')}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Master Timeline Lip-Sync & Offset Alignment Card ("ကွက်တိ အသံအနေထား ထားပေးမာ") */}
          <div className="p-5 rounded-2xl bg-slate-950/80 border border-rose-500/40 space-y-3.5 shadow-lg shadow-rose-500/10">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-rose-300 flex items-center gap-1.5">
                <Waveform className="w-4 h-4 text-rose-400" />
                <span>{isMy ? 'အသံ အချိန် အသေးစိတ် ချိန်ညှိမှု (Offset):' : 'Master Audio Offset:'}</span>
              </span>
              <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-mono text-xs font-bold">
                {syncOffsetSec > 0 ? `+${syncOffsetSec.toFixed(2)}s` : `${syncOffsetSec.toFixed(2)}s`}
              </span>
            </div>

            <p className="text-[11px] text-slate-400">
              {isMy
                ? 'အသံတစ်ခုလုံးကို ဗီဒီယိုနှင့် စက္ကန့်ပိုင်းအလိုက် ရှေ့တိုး/နောက်ဆုတ် ညှိပါ'
                : 'Nudge entire audio track forward or backward for frame-perfect sync'}
            </p>

            <input
              type="range"
              min={-3.0}
              max={3.0}
              step={0.05}
              value={syncOffsetSec}
              onChange={(e) => handleOffsetChange(parseFloat(e.target.value))}
              className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />

            {/* Quick offset buttons */}
            <div className="flex flex-wrap items-center justify-between gap-1 text-xs font-mono">
              <button
                type="button"
                onClick={() => handleOffsetChange(syncOffsetSec - 0.2)}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800"
              >
                -0.2s
              </button>
              <button
                type="button"
                onClick={() => handleOffsetChange(syncOffsetSec - 0.1)}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800"
              >
                -0.1s
              </button>
              <button
                type="button"
                onClick={() => handleOffsetChange(0.0)}
                className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-rose-300 rounded-lg border border-slate-800 font-bold"
              >
                {isMy ? '0.0s (Reset)' : 'Reset 0.0s'}
              </button>
              <button
                type="button"
                onClick={() => handleOffsetChange(syncOffsetSec + 0.1)}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800"
              >
                +0.1s
              </button>
              <button
                type="button"
                onClick={() => handleOffsetChange(syncOffsetSec + 0.2)}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800"
              >
                +0.2s
              </button>
            </div>

            {/* Speech Tempo / Speed Matching */}
            <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-300 font-medium">
                  {isMy ? 'စကားပြောနှုန်း (Voice Tempo):' : 'Voice Tempo Speed:'}
                </span>
                <span className="font-mono text-rose-400 font-bold">{voicePlaybackSpeed}x</span>
              </div>
              <div className="flex items-center gap-1">
                {[0.9, 0.95, 1.0, 1.05, 1.1].map((spd) => (
                  <button
                    key={spd}
                    type="button"
                    onClick={() => setVoicePlaybackSpeed(spd)}
                    className={`flex-1 py-1 rounded text-[10px] font-mono transition ${
                      voicePlaybackSpeed === spd
                        ? 'bg-rose-600 text-white font-bold'
                        : 'bg-slate-900 text-slate-400 hover:text-white'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Dual Volume Mixer Card */}
          <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
              <Sliders className="w-4 h-4 text-rose-400" />
              <span>{isMy ? 'အသံ အချိုးအစား ချိန်ညှိမှု (Audio Mixer)' : 'Dual Audio Track Mixer'}</span>
            </div>

            {/* 1. Dubbed Burmese Voice Volume */}
            <div className="space-y-1.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-rose-300 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-rose-400" />
                  <span>{isMy ? '🇲🇲 မြန်မာဘာသာ အသံ (Dubbed Voice):' : 'Burmese Dubbed Voice:'}</span>
                </span>
                <span className="font-mono text-white font-bold">{Math.round(dubbedVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={2}
                step={0.05}
                value={dubbedVolume}
                onChange={(e) => setDubbedVolume(parseFloat(e.target.value))}
                className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex items-center gap-2 pt-1 text-[10px]">
                <button
                  type="button"
                  onClick={() => setDubbedVolume(1.0)}
                  className={`px-2 py-0.5 rounded transition ${
                    dubbedVolume === 1.0 ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  100% {isMy ? '(ပုံမှန်)' : '(Normal)'}
                </button>
                <button
                  type="button"
                  onClick={() => setDubbedVolume(1.5)}
                  className={`px-2 py-0.5 rounded transition ${
                    dubbedVolume === 1.5 ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  150% {isMy ? '(အသံမြှင့်)' : '(Boosted)'}
                </button>
              </div>
            </div>

            {/* 2. Original Video Audio Volume */}
            <div className="space-y-1.5 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                  {originalVolume === 0 ? <VolumeX className="w-3.5 h-3.5 text-slate-500" /> : <Volume2 className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{isMy ? '🌐 မူရင်းဗီဒီယို အသံ (Original Audio):' : 'Original Video Audio:'}</span>
                </span>
                <span className="font-mono text-white font-bold">{Math.round(originalVolume * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={originalVolume}
                onChange={(e) => setOriginalVolume(parseFloat(e.target.value))}
                className="w-full accent-slate-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setOriginalVolume(0)}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium transition ${
                    originalVolume === 0
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {isMy ? 'အသံပိတ် (Mute 0%)' : 'Mute (0%)'}
                </button>
                <button
                  type="button"
                  onClick={() => setOriginalVolume(0.1)}
                  className={`px-2 py-0.5 rounded text-[10px] font-medium transition ${
                    originalVolume === 0.1
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {isMy ? 'နောက်ခံသံ (BGM 10%)' : 'BGM (10%)'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
