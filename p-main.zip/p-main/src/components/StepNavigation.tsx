import React from 'react';
import { KeyRound, UploadCloud, Cpu, FileText, Mic, Film, Check } from 'lucide-react';
import { AppLanguage } from '../types';

interface StepNavigationProps {
  currentStep: number;
  onSelectStep: (step: number) => void;
  apiKeyConnected: boolean;
  hasVideo: boolean;
  hasTranscript: boolean;
  hasVoiceAudio?: boolean;
  appLang: AppLanguage;
}

export const StepNavigation: React.FC<StepNavigationProps> = ({
  currentStep,
  onSelectStep,
  apiKeyConnected,
  hasVideo,
  hasTranscript,
  hasVoiceAudio,
  appLang,
}) => {
  const isMy = appLang === 'my';

  const steps = [
    {
      step: 1,
      title: isMy ? 'အဆင့် ၁: API Key' : 'Step 1: API Key',
      subtitle: isMy ? 'Gemini API ချိတ်ရန်' : 'Connect Gemini API',
      icon: KeyRound,
      isCompleted: apiKeyConnected,
      isEnabled: true,
    },
    {
      step: 2,
      title: isMy ? 'အဆင့် ၂: Video တင်ရန်' : 'Step 2: Upload',
      subtitle: isMy ? 'ဗီဒီယို ဖိုင်တင်ရန်' : 'Upload video file',
      icon: UploadCloud,
      isCompleted: hasVideo,
      isEnabled: apiKeyConnected,
    },
    {
      step: 3,
      title: isMy ? 'အဆင့် ၃: စာသားပြောင်း' : 'Step 3: Transcribe',
      subtitle: isMy ? 'Gemini AI စာသားပြောင်း' : 'AI Speech to Text',
      icon: Cpu,
      isCompleted: hasTranscript,
      isEnabled: apiKeyConnected && hasVideo,
    },
    {
      step: 4,
      title: isMy ? 'အဆင့် ၄: စာသား & TXT' : 'Step 4: TXT Export',
      subtitle: isMy ? 'စာသားဖတ်ရှု / ဒေါင်းလုဒ်' : 'View & Download TXT',
      icon: FileText,
      isCompleted: hasTranscript,
      isEnabled: hasTranscript,
    },
    {
      step: 5,
      title: isMy ? 'အဆင့် ၅: Voice Clone' : 'Step 5: Voice Clone',
      subtitle: isMy ? 'မြန်မာ အသံဖန်တီးရန်' : 'Burmese Voice TTS',
      icon: Mic,
      isCompleted: Boolean(hasVoiceAudio),
      isEnabled: hasTranscript,
    },
    {
      step: 6,
      title: isMy ? 'အဆင့် ၆: Video Dubbing' : 'Step 6: Video Dubbing',
      subtitle: isMy ? 'ဗီဒီယိုနှင့် အသံ ပေါင်းစပ်' : 'Merge Audio & Video',
      icon: Film,
      isCompleted: Boolean(hasVoiceAudio),
      isEnabled: hasVideo && hasTranscript,
    },
  ];

  return (
    <div className="w-full bg-slate-900/60 border-y border-slate-800/80 px-4 py-4 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {steps.map((s) => {
          const Icon = s.icon;
          const isActive = currentStep === s.step;
          const isDone = s.isCompleted;
          const isClickable = s.isEnabled;

          return (
            <button
              key={s.step}
              onClick={() => isClickable && onSelectStep(s.step)}
              disabled={!isClickable}
              className={`relative flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-all duration-200 ${
                isActive
                  ? 'bg-rose-600/15 border-rose-500 shadow-lg shadow-rose-500/10 ring-1 ring-rose-500'
                  : isDone
                  ? 'bg-slate-800/60 border-slate-700 hover:border-slate-600 hover:bg-slate-800 cursor-pointer'
                  : isClickable
                  ? 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700 cursor-pointer'
                  : 'bg-slate-900/20 border-slate-800/40 opacity-40 cursor-not-allowed'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                  isDone
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : isActive
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-500/30'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {isDone ? <Check className="w-4 h-4 stroke-[2.5]" /> : <Icon className="w-4 h-4" />}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <span
                    className={`text-[11px] font-bold truncate ${
                      isActive ? 'text-rose-400' : isDone ? 'text-emerald-400' : 'text-slate-200'
                    }`}
                  >
                    {s.title}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 truncate">{s.subtitle}</p>
              </div>

              {isActive && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-6 h-1 rounded-full bg-rose-500 shadow-sm" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
