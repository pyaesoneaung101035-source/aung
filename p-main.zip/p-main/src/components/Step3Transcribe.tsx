import React from 'react';
import { Cpu, Sparkles, Loader2, Clock, Users, FileCheck2, Globe2, AlertCircle } from 'lucide-react';
import { AppLanguage, TranscribeOptions } from '../types';

interface Step3TranscribeProps {
  options: TranscribeOptions;
  setOptions: React.Dispatch<React.SetStateAction<TranscribeOptions>>;
  isTranscribing: boolean;
  transcribeProgressMessage: string;
  onStartTranscribe: () => void;
  appLang: AppLanguage;
  errorMsg: string | null;
  videoFileName: string;
}

export const Step3Transcribe: React.FC<Step3TranscribeProps> = ({
  options,
  setOptions,
  isTranscribing,
  transcribeProgressMessage,
  onStartTranscribe,
  appLang,
  errorMsg,
  videoFileName,
}) => {
  const isMy = appLang === 'my';

  const languages = [
    { id: 'auto', label: isMy ? 'အလိုအလျောက် မှတ်သားမည် (Auto-detect)' : 'Auto-detect' },
    { id: 'my', label: isMy ? 'မြန်မာဘာသာ သီးသန့် (Burmese)' : 'Burmese (မြန်မာ)' },
    { id: 'en', label: isMy ? 'အင်္ဂလိပ်ဘာသာ (English)' : 'English' },
    { id: 'bilingual', label: isMy ? 'မြန်မာ + English ရောနှော (Bilingual)' : 'Bilingual (Burmese + English)' },
  ];

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl relative overflow-hidden backdrop-blur-xl">
      {/* Background glow */}
      <div className="absolute top-0 right-0 -mt-16 -mr-16 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center text-white shadow-lg shadow-purple-500/25">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-400 bg-purple-500/10 px-2.5 py-0.5 rounded-full border border-purple-500/20">
                {isMy ? 'အဆင့် ၃' : 'Step 3'}
              </span>
              <h2 className="text-xl font-bold text-white">
                {isMy ? 'Gemini AI ဖြင့် စာသားထုတ်ယူခြင်း' : 'Transcribe with Gemini AI'}
              </h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">
              {isMy
                ? `တင်ထားသော "${videoFileName}" မှ စာသားများကို Gemini 3.8 Flash ဖြင့် တိကျစွာ ပြောင်းလဲထုတ်ယူပါမည်`
                : `Transcribe speech from "${videoFileName}" into accurate text using Gemini 3.8 Flash`}
            </p>
          </div>
        </div>
      </div>

      {/* Settings & Options */}
      <div className="mt-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Language Selector */}
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-slate-200 text-sm font-semibold">
              <Globe2 className="w-4 h-4 text-purple-400" />
              <span>{isMy ? 'ပြောဆိုသည့် ဘာသာစကား (Language)' : 'Spoken Language'}</span>
            </div>
            <p className="text-xs text-slate-400">
              {isMy ? 'ဗီဒီယိုအတွင်း ပြောဆိုထားသော အဓိက ဘာသာစကားကို ရွေးပါ' : 'Select the primary language spoken in the video'}
            </p>

            <div className="grid grid-cols-1 gap-2 pt-1">
              {languages.map((lang) => (
                <label
                  key={lang.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border text-xs cursor-pointer transition ${
                    options.language === lang.id
                      ? 'bg-purple-600/15 border-purple-500/60 text-purple-300 font-medium'
                      : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="language"
                    value={lang.id}
                    checked={options.language === lang.id}
                    onChange={() => setOptions((prev) => ({ ...prev, language: lang.id as any }))}
                    className="text-purple-600 focus:ring-purple-500 bg-slate-900 border-slate-700"
                  />
                  <span>{lang.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Transcript Format Options */}
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-2 text-slate-200 text-sm font-semibold">
              <FileCheck2 className="w-4 h-4 text-pink-400" />
              <span>{isMy ? 'စာသားဖွဲ့စည်းပုံ ရွေးချယ်မှုများ' : 'Formatting & Features'}</span>
            </div>

            <div className="space-y-3 pt-1">
              {/* Translate all to Burmese - PRIMARY FEATURE REQUESTED */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-emerald-500/50 bg-emerald-500/10 hover:bg-emerald-500/15 cursor-pointer transition">
                <input
                  type="checkbox"
                  checked={options.translateToBurmese}
                  onChange={(e) => setOptions((prev) => ({ ...prev, translateToBurmese: e.target.checked }))}
                  className="mt-0.5 text-emerald-600 focus:ring-emerald-500 rounded bg-slate-900 border-slate-700"
                />
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-300">
                    <Globe2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{isMy ? 'ဘာသာစကား အားလုံးကို မြန်မာဘာသာသို့ အပြည့်အစုံ ပြန်ဆိုမည် (Translate to Burmese)' : 'Translate All Speech to Burmese'}</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {isMy ? 'ဖွင့်ထားသည်' : 'Active'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    {isMy
                      ? 'မည်သည့် ဘာသာစကား (အင်္ဂလိပ်၊ တရုတ်၊ ဂျပန် စသည်) ဖြင့် ပြောထားစေကာမူ မြန်မာစာသားစစ်စစ်ဖြင့် အပြည့်အစုံ ပြန်ဆိုပေးပါမည်'
                      : 'Automatically translates any spoken language (English, etc.) into fluent, natural Burmese text'}
                  </p>
                </div>
              </label>

              {/* Exact Timestamps - PRIMARY FEATURE REQUESTED */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-purple-500/50 bg-purple-500/10 hover:bg-purple-500/15 cursor-pointer transition">
                <input
                  type="checkbox"
                  checked={options.exactTimestamps}
                  onChange={(e) => setOptions((prev) => ({ ...prev, exactTimestamps: e.target.checked }))}
                  className="mt-0.5 text-purple-600 focus:ring-purple-500 rounded bg-slate-900 border-slate-700"
                />
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-purple-300">
                    <Clock className="w-3.5 h-3.5 text-purple-400" />
                    <span>{isMy ? 'စကားတစ်ကြောင်းချင်းစီ အချိန်မှတ်သားချက် အတိအကျ ထည့်မည် (Exact Timestamps)' : 'Exact Timestamps per Sentence'}</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-purple-500/20 text-purple-400 border border-purple-500/30">
                      {isMy ? 'တိကျစွာ မှတ်သားမည်' : 'Exact Time'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    {isMy
                      ? 'စကားစတင်ချိန်နှင့် ပြီးဆုံးချိန် [00:02 - 00:07] အတိအကျကို စာသားလိုင်းတိုင်းတွင် ထည့်သွင်းပေးပါမည်'
                      : 'Captures precise start & end boundaries [00:02 - 00:07] for each sentence in the transcript and TXT'}
                  </p>
                </div>
              </label>

              {/* Speaker Diarization */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-800 bg-slate-900/40 hover:border-slate-700 cursor-pointer transition">
                <input
                  type="checkbox"
                  checked={options.diarization}
                  onChange={(e) => setOptions((prev) => ({ ...prev, diarization: e.target.checked }))}
                  className="mt-0.5 text-purple-600 focus:ring-purple-500 rounded bg-slate-900 border-slate-700"
                />
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                    <Users className="w-3.5 h-3.5 text-pink-400" />
                    <span>{isMy ? 'ပြောဆိုသူ ခွဲခြားသတ်မှတ်မည် (Speaker Diarization)' : 'Speaker Identification'}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {isMy ? 'ပြောဆိုသူ ၁၊ ပြောဆိုသူ ၂ စသည်ဖြင့် အသံကွဲပြားမှုကို ခွဲခြားမှတ်တမ်းတင်မည်' : 'Distinguishes different speakers in conversations'}
                  </p>
                </div>
              </label>

              {/* Summary */}
              <label className="flex items-start gap-3 p-3 rounded-xl border border-slate-800 bg-slate-900/40 hover:border-slate-700 cursor-pointer transition">
                <input
                  type="checkbox"
                  checked={options.generateSummary}
                  onChange={(e) => setOptions((prev) => ({ ...prev, generateSummary: e.target.checked }))}
                  className="mt-0.5 text-purple-600 focus:ring-purple-500 rounded bg-slate-900 border-slate-700"
                />
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>{isMy ? 'မြန်မာဘာသာဖြင့် အနှစ်ချုပ်နှင့် အဓိကအချက်များ ထုတ်ယူမည် (Burmese Summary)' : 'Generate Burmese AI Summary & Key Points'}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {isMy ? 'ဗီဒီယို၏ အဓိကဆိုလိုရင်းကို မြန်မာဘာသာဖြင့် အနှစ်ချုပ် ထုတ်ပေးမည်' : 'Generates a concise overview in Burmese'}
                  </p>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="flex items-center gap-2.5 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Progress or CTA */}
        {isTranscribing ? (
          <div className="bg-slate-950/80 border border-purple-500/40 rounded-2xl p-6 text-center space-y-4 shadow-xl">
            <div className="relative w-14 h-14 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-purple-500/20 border-t-purple-500 animate-spin" />
              <Sparkles className="w-6 h-6 text-purple-400 animate-pulse" />
            </div>

            <div>
              <h4 className="text-sm font-bold text-white">
                {isMy ? 'Gemini AI ဖြင့် စာသား ထုတ်ယူနေပါသည်...' : 'Gemini AI is transcribing your video...'}
              </h4>
              <p className="text-xs text-purple-300/90 font-medium mt-1">
                {transcribeProgressMessage || (isMy ? 'ဗီဒီယိုကို စစ်ဆေးနေပါသည်...' : 'Processing video track...')}
              </p>
            </div>

            {/* Simulated Animated Pulse Step Bar */}
            <div className="w-full max-w-md mx-auto bg-slate-800 rounded-full h-2 overflow-hidden relative">
              <div className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 animate-[pulse_1.5s_infinite] w-full" />
            </div>

            <p className="text-[11px] text-slate-500">
              {isMy
                ? 'ဗီဒီယို အရှည်ပေါ်မူတည်၍ စက္ကန့်အနည်းငယ် ကြာနိုင်ပါသည်'
                : 'Processing time depends on video length (usually 5-20 seconds)'}
            </p>
          </div>
        ) : (
          <div className="pt-2">
            <button
              onClick={onStartTranscribe}
              className="w-full flex items-center justify-center gap-3 py-4 px-6 rounded-2xl text-sm font-bold text-white bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:from-purple-500 hover:via-pink-500 hover:to-indigo-500 shadow-xl shadow-purple-600/30 transition transform active:scale-[0.99] cursor-pointer"
            >
              <Sparkles className="w-5 h-5 text-purple-200" />
              <span>{isMy ? 'စာသား စတင်ထုတ်ယူမည် (Generate Transcript)' : 'Start AI Transcription'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
