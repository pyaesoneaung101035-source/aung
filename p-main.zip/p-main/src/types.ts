export interface TranscriptSegment {
  start: string;       // Exact start timestamp e.g. "00:02" or "00:00:02"
  end: string;         // Exact end timestamp e.g. "00:07" or "00:00:07"
  speaker?: string;    // e.g. "ပြောဆိုသူ ၁" or "Speaker 1"
  burmeseText: string; // Accurate Burmese translation
  originalText: string;// Spoken original language text
  text: string;        // Primary display text (Burmese)
}

export interface TranscriptionResult {
  id: string;
  timestamp: number;
  fileName: string;
  fileSizeFormatted: string;
  durationFormatted: string;
  detectedLanguage: string;
  plainText: string;              // Primary Burmese plain text with exact timestamps
  burmeseTranscript: string;      // Full Burmese translation with exact timestamps
  originalTranscript: string;     // Full Original transcript with exact timestamps
  bilingualTranscript: string;    // Side-by-side / interleaved with exact timestamps
  formattedTranscript: string;
  segments: TranscriptSegment[];
  summary: string;                // Burmese summary
  keyPoints: string[];            // Burmese key points
  srtContent: string;             // Burmese subtitle format
  originalSrtContent?: string;    // Original subtitle format
}

export type AppLanguage = 'my' | 'en';

export interface TranscribeOptions {
  language: 'auto' | 'my' | 'en' | 'bilingual';
  translateToBurmese: boolean;    // Always translate all output to Burmese
  includeTimestamps: boolean;
  exactTimestamps: boolean;        // Precise start-end time ranges [00:00 - 00:05]
  diarization: boolean;
  generateSummary: boolean;
}

export type VoiceCloneMode = 'preset' | 'clone' | 'prompt';

export interface VoiceCloneOptions {
  engine: 'voxcpm' | 'gemini_tts';
  voxcpmUrl: string;
  mode: VoiceCloneMode;
  presetVoice: string; // e.g. "🗣️ ခိုင်ခိုင်", "🗣️ ကျော်ကျော်", "🗣️ မျိုးသန့်", "🗣️ သဇင်", "🎙️ ကိုကို (Host)"
  referenceAudioBase64?: string;
  referenceAudioName?: string;
  referenceText?: string;
  stylePrompt?: string;
  speed: number;
}

export interface VoiceCloneAudioResult {
  id: string;
  audioUrl: string;
  base64?: string;
  mimeType: string;
  generatedText: string;
  voiceName: string;
  engine: string;
  mode: VoiceCloneMode;
  timestamp: number;
  isTimeAligned?: boolean; // True when silence gaps are baked into timestamps
  segmentCount?: number;
}

export interface DubbedVideoOptions {
  originalAudioVolume: number; // 0.0 to 1.0 (default 0 for complete replacement)
  dubbedAudioVolume: number;   // 0.0 to 2.0 (default 1.0)
  audioSyncOffsetSec: number;  // -3.0 to +3.0 seconds fine-tuning
  showSubtitleOverlay: boolean;// overlay Burmese subtitles on video
}
