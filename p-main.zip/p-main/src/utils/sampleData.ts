/**
 * Provides demo sample audio/video generators for instant 1-click testing.
 */

// Generates a short synthetic audio file for demonstration
export function generateTestSpeechBlob(title: string, durationSec = 3): File {
  const sampleRate = 16000;
  const numFrames = sampleRate * durationSec;
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
  const buffer = audioContext.createBuffer(1, numFrames, sampleRate);
  const data = buffer.getChannelData(0);

  // Generate pleasant harmonic chord tones representing speech rhythms
  for (let i = 0; i < numFrames; i++) {
    const t = i / sampleRate;
    const envelope = Math.sin(Math.PI * (i / numFrames));
    const tone1 = Math.sin(2 * Math.PI * 220 * t);
    const tone2 = Math.sin(2 * Math.PI * 440 * t) * 0.5;
    const tone3 = Math.sin(2 * Math.PI * 880 * t) * 0.25;
    data[i] = (tone1 + tone2 + tone3) * 0.2 * envelope;
  }

  // Convert buffer to WAV
  const length = numFrames * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));

  function setUint16(pos: number, val: number) {
    out.setUint16(pos, val, true);
  }
  function setUint32(pos: number, val: number) {
    out.setUint32(pos, val, true);
  }

  setUint32(0, 0x46464952); // "RIFF"
  setUint32(4, length - 8);
  setUint32(8, 0x45564157); // "WAVE"
  setUint32(12, 0x20746d66); // "fmt "
  setUint32(16, 16);
  setUint16(20, 1);
  setUint16(22, 1);
  setUint32(24, sampleRate);
  setUint32(28, sampleRate * 2);
  setUint16(32, 2);
  setUint16(34, 16);
  setUint32(36, 0x61746164); // "data"
  setUint32(40, length - 44);

  let p = 44;
  for (let i = 0; i < numFrames; i++) {
    const sample = Math.max(-1, Math.min(1, data[i]));
    out.setInt16(p, sample < 0 ? sample * 32768 : sample * 32767, true);
    p += 2;
  }

  const blob = new Blob([out.buffer], { type: 'audio/wav' });
  return new File([blob], `${title.replace(/\s+/g, '_').toLowerCase()}.wav`, { type: 'audio/wav' });
}
