/**
 * Audio Synchronization and Timeline Assembly Helper
 * Aligns synthesized Burmese speech segments with exact video transcript timestamps.
 * Guarantees that each dialogue segment plays at its exact start timestamp (e.g. 00:00 -> 00:06, then 00:06 -> 00:10)
 * with natural silence padding between segments and auto-fit speed for long sentences.
 */

import { TranscriptSegment, VoiceCloneAudioResult } from '../types';

/**
 * Safe fetch helper that validates JSON responses and prevents
 * "Unexpected token '<', '<!doctype '... is not valid JSON" errors
 * when the server or gateway returns an HTML error page.
 */
export async function safeFetchJson<T = any>(url: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, init);
  } catch (netErr: any) {
    throw new Error(`ကွန်ရက် ချိတ်ဆက်မှု အမှား (Network Error): ${netErr?.message || 'Failed to connect to server'}`);
  }

  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    const rawText = await res.text().catch(() => '');
    if (rawText.includes('<!doctype') || rawText.includes('<!DOCTYPE') || rawText.includes('<html')) {
      throw new Error(
        `ဆာဗာမှ ယာယီ တုံ့ပြန်မှု နှောင့်နှေးနေပါသည် (${res.status} ${res.statusText})။ ကျေးဇူးပြု၍ ခေတ္တစောင့်ပြီး ထပ်မံကြိုးစားပါ။`
      );
    }
    throw new Error(rawText ? rawText.slice(0, 150) : `ဆာဗာ တုံ့ပြန်မှု မအောင်မြင်ပါ (${res.status})`);
  }

  try {
    return (await res.json()) as T;
  } catch {
    throw new Error('ဆာဗာမှ ဒေတာဖတ်ရှုရာတွင် အမှားဖြစ်ပေါ်ပါသည် (Invalid JSON format)');
  }
}

/**
 * Parses time strings like "00:03", "00:03.50", "00:00:03", "[00:03]" or raw numbers into seconds.
 */
export function parseTimestampToSeconds(timeVal: string | number): number {
  if (timeVal === undefined || timeVal === null) return 0;
  if (typeof timeVal === 'number') return Math.max(0, timeVal);
  const clean = String(timeVal).trim().replace(/^\[|\]$/g, '').trim();
  const parts = clean.split(':').map((p) => parseFloat(p));
  if (parts.length === 1 && !isNaN(parts[0])) {
    return Math.max(0, parts[0]);
  }
  if (parts.length === 2) {
    return Math.max(0, (parts[0] || 0) * 60 + (parts[1] || 0));
  }
  if (parts.length === 3) {
    return Math.max(0, (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0));
  }
  return 0;
}

/**
 * Formats seconds into MM:SS.ms or MM:SS
 */
export function formatSecondsToTime(seconds: number, includeMs = false): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 10);
  const base = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return includeMs ? `${base}.${ms}` : base;
}

/**
 * Encodes an AudioBuffer into a standard 16-bit PCM WAV Blob.
 */
export function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;

  const dataLength = buffer.length * blockAlign;
  const bufferLength = 44 + dataLength;

  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  /* RIFF identifier */
  writeString(0, 'RIFF');
  /* file length */
  view.setUint32(4, 36 + dataLength, true);
  /* RIFF type */
  writeString(8, 'WAVE');
  /* format chunk identifier */
  writeString(12, 'fmt ');
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw) */
  view.setUint16(20, format, true);
  /* channel count */
  view.setUint16(22, numChannels, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sample rate * block align) */
  view.setUint32(28, sampleRate * blockAlign, true);
  /* block align (channel count * bytes per sample) */
  view.setUint16(32, blockAlign, true);
  /* bits per sample */
  view.setUint16(34, bitDepth, true);
  /* data chunk identifier */
  writeString(36, 'data');
  /* data chunk length */
  view.setUint32(40, dataLength, true);

  // Interleave channels and write 16-bit PCM samples
  const channels: Float32Array[] = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(buffer.getChannelData(c));
  }

  let offset = 44;
  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      let sample = channels[c][i];
      sample = Math.max(-1, Math.min(1, sample));
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([view], { type: 'audio/wav' });
}

export interface SegmentAudioItem {
  index: number;
  startSec: number;
  endSec: number;
  durationSlotSec?: number;
  text: string;
  audioBase64?: string;
  audioBuffer?: AudioBuffer;
  isLongText?: boolean;
  actualDurationSec?: number;
  appliedSpeed?: number;
}

export interface AssemblyOptions {
  totalVideoDuration?: number;
  speechSpeed?: number; // User general tempo multiplier (default 1.0)
  autoFitLongText?: boolean; // When text is long, automatically compress tempo so it finishes before next segment
}

/**
 * Builds a single master AudioBuffer that aligns all speech segments
 * to the exact video timeline. Silence is preserved during pauses.
 *
 * Example:
 * Segment 0: 00:00 - 00:06 -> "မင်္ဂလာပါ" starts at 00:00, finishes, then silence until 00:06.
 * Segment 1: 00:06 - 00:10 -> "ဘာတွေလုပ်နေလဲ" starts at 00:06, finishes, then silence until 00:10.
 *
 * For long sentences:
 * If the generated speech is longer than the subtitle duration (e.g. speech is 8s, slot is 6s),
 * it dynamically speeds up that segment (e.g. 1.35x) so it finishes 0.15s BEFORE 00:06,
 * ensuring the subsequent audio never lags behind!
 */
export async function assembleTimelineAudio(
  audioCtx: AudioContext,
  segmentAudios: SegmentAudioItem[],
  totalDurationSec: number,
  playbackSpeed = 1.0,
  autoFitLongText = true
): Promise<{ masterBuffer: AudioBuffer; processedSegments: SegmentAudioItem[] }> {
  const sampleRate = audioCtx.sampleRate || 44100;

  // Determine timeline length
  let maxEndTime = totalDurationSec > 0 ? totalDurationSec : 10;
  for (const item of segmentAudios) {
    if (item.endSec > maxEndTime) {
      maxEndTime = item.endSec + 1;
    }
  }

  const totalLength = Math.max(1, Math.ceil(maxEndTime * sampleRate));
  const masterBuffer = audioCtx.createBuffer(1, totalLength, sampleRate);
  const masterData = masterBuffer.getChannelData(0);

  const processedSegments: SegmentAudioItem[] = [];

  for (let sIdx = 0; sIdx < segmentAudios.length; sIdx++) {
    const item = segmentAudios[sIdx];
    if (!item.audioBuffer) {
      processedSegments.push(item);
      continue;
    }

    const sourceData = item.audioBuffer.getChannelData(0);
    const sourceDurationSec = item.audioBuffer.duration;
    // Guaranteed sample lock to exact startSec
    const targetStartSample = Math.max(0, Math.floor(item.startSec * sampleRate));

    // Calculate maximum available slot duration until next segment or item.endSec
    const nextItem = segmentAudios[sIdx + 1];
    let availableSlotSec = item.endSec - item.startSec;
    if (nextItem && nextItem.startSec > item.startSec) {
      availableSlotSec = Math.max(0.6, nextItem.startSec - item.startSec);
    } else {
      availableSlotSec = Math.max(0.6, availableSlotSec);
    }

    // Target max duration to leave 0.15s natural pause before next subtitle starts
    const targetSlotSec = Math.max(0.5, availableSlotSec - 0.15);

    // Compute effective speed:
    // If autoFitLongText is true and the speech is longer than the slot, speed it up to fit!
    let effectiveSpeed = playbackSpeed;
    if (autoFitLongText && sourceDurationSec / effectiveSpeed > targetSlotSec) {
      // Scale faster to guarantee it finishes cleanly before the next segment starts
      const neededSpeed = sourceDurationSec / targetSlotSec;
      // Cap at 1.7x to preserve intelligibility
      effectiveSpeed = Math.min(1.7, Math.max(playbackSpeed, neededSpeed * playbackSpeed));
    }

    const resampledLen = Math.floor(sourceData.length / effectiveSpeed);
    const actualSegmentDuration = resampledLen / sampleRate;

    if (effectiveSpeed === 1.0) {
      for (let i = 0; i < sourceData.length; i++) {
        const destIdx = targetStartSample + i;
        if (destIdx < totalLength) {
          masterData[destIdx] += sourceData[i];
        }
      }
    } else {
      // Linear resampling with end-fade to prevent pops
      const fadeLen = Math.min(Math.floor(sampleRate * 0.02), resampledLen); // 20ms fade
      for (let i = 0; i < resampledLen; i++) {
        const srcIdx = Math.floor(i * effectiveSpeed);
        const destIdx = targetStartSample + i;
        if (destIdx < totalLength && srcIdx < sourceData.length) {
          let sample = sourceData[srcIdx];
          // Smooth fade out at the very end
          if (i >= resampledLen - fadeLen) {
            const fade = (resampledLen - i) / fadeLen;
            sample *= fade;
          }
          masterData[destIdx] += sample;
        }
      }
    }

    processedSegments.push({
      ...item,
      appliedSpeed: parseFloat(effectiveSpeed.toFixed(2)),
      actualDurationSec: parseFloat(actualSegmentDuration.toFixed(2)),
    });
  }

  // Normalize to prevent digital clipping
  let maxAmp = 0;
  for (let i = 0; i < masterData.length; i++) {
    const abs = Math.abs(masterData[i]);
    if (abs > maxAmp) maxAmp = abs;
  }
  if (maxAmp > 0.95) {
    const scale = 0.95 / maxAmp;
    for (let i = 0; i < masterData.length; i++) {
      masterData[i] *= scale;
    }
  }

  return { masterBuffer, processedSegments };
}

/**
 * High-level function to synthesize and build a full time-aligned Burmese audio track.
 */
export async function buildCompleteTimeAlignedTrack(params: {
  segments: TranscriptSegment[];
  presetVoice: string;
  apiKey?: string;
  totalVideoDuration?: number;
  speechSpeed?: number;
  onProgress?: (message: string) => void;
}): Promise<VoiceCloneAudioResult> {
  const {
    segments,
    presetVoice,
    apiKey,
    totalVideoDuration = 0,
    speechSpeed = 1.0,
    onProgress,
  } = params;

  onProgress?.('စာတန်းထိုး အပိုင်းလိုက် အသံများကို Gemini TTS ဖြင့် ထုတ်ယူနေပါသည်...');

  const segmentsToProcess = segments.map((seg, idx) => ({
    index: idx,
    start: seg.start,
    end: seg.end,
    text: seg.burmeseText || seg.text,
    burmeseText: seg.burmeseText || seg.text,
  }));

  const data = await safeFetchJson<{
    success: boolean;
    segmentAudios: Array<{
      index: number;
      startSec: number;
      endSec: number;
      durationSlotSec: number;
      text: string;
      audioBase64?: string;
      isLongText?: boolean;
    }>;
    error?: string;
  }>('/api/voice-clone/generate-segments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      segments: segmentsToProcess,
      presetVoice,
      apiKey,
    }),
  });

  if (!data.success || !data.segmentAudios) {
    throw new Error(data.error || 'အသံထုတ်ယူရာတွင် အမှားဖြစ်ပေါ်ပါသည်');
  }

  onProgress?.('ဗီဒီယို စာတန်းထိုး အချိန်နှင့် ကွက်တိကိုက်ညီအောင် ပေါင်းစပ်နေပါသည်...');

  const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  const segmentAudioItems: SegmentAudioItem[] = [];

  for (const item of data.segmentAudios) {
    if (!item.audioBase64) continue;
    try {
      const byteCharacters = atob(item.audioBase64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let j = 0; j < byteCharacters.length; j++) {
        byteNumbers[j] = byteCharacters.charCodeAt(j);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const audioBuffer = await audioCtx.decodeAudioData(byteArray.buffer.slice(0));

      segmentAudioItems.push({
        index: item.index,
        startSec: item.startSec,
        endSec: item.endSec,
        durationSlotSec: item.durationSlotSec,
        text: item.text,
        audioBuffer,
        isLongText: item.isLongText,
      });
    } catch (e) {
      console.warn(`Failed to decode segment ${item.index} audio:`, e);
    }
  }

  if (segmentAudioItems.length === 0) {
    throw new Error('အသံဖိုင်များ ပေါင်းစပ်၍ မရပါ (No valid audio decoded from TTS)');
  }

  const { masterBuffer } = await assembleTimelineAudio(
    audioCtx,
    segmentAudioItems,
    totalVideoDuration,
    speechSpeed,
    true // autoFitLongText = true
  );

  const wavBlob = audioBufferToWavBlob(masterBuffer);
  const masterWavUrl = URL.createObjectURL(wavBlob);

  const fullText = segments.map((s) => s.burmeseText || s.text).join('။ ');

  return {
    id: 'aligned_' + Date.now(),
    audioUrl: masterWavUrl,
    mimeType: 'audio/wav',
    generatedText: fullText,
    voiceName: `${presetVoice} (Time-Aligned)`,
    engine: 'Gemini Burmese TTS (Time-Aligned Video Sync)',
    mode: 'preset',
    timestamp: Date.now(),
    isTimeAligned: true,
    segmentCount: segmentAudioItems.length,
  };
}
