/**
 * Video & Audio synchronization and dubbing export utility.
 */

export async function mergeVideoAndAudioClient(
  videoEl: HTMLVideoElement,
  audioEl: HTMLAudioElement,
  onProgress?: (progressPercent: number) => void
): Promise<Blob> {
  return new Promise(async (resolve, reject) => {
    try {
      // Create offscreen canvas for rendering
      const width = videoEl.videoWidth || 1280;
      const height = videoEl.videoHeight || 720;
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        throw new Error('Canvas 2D context not available');
      }

      // Audio setup
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const dest = audioCtx.createMediaStreamDestination();

      const audioSource = audioCtx.createMediaElementSource(audioEl);
      audioSource.connect(dest);
      audioSource.connect(audioCtx.destination); // Also hear during preview if needed

      // Canvas stream
      const videoStream = canvas.captureStream(30); // 30 FPS
      const combinedStream = new MediaStream([
        videoStream.getVideoTracks()[0],
        dest.stream.getAudioTracks()[0],
      ]);

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : MediaRecorder.isTypeSupported('video/mp4')
        ? 'video/mp4'
        : 'video/webm';

      const recorder = new MediaRecorder(combinedStream, {
        mimeType,
        videoBitsPerSecond: 3000000, // 3 Mbps
      });

      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      recorder.onstop = () => {
        const finalBlob = new Blob(chunks, { type: mimeType });
        audioCtx.close();
        resolve(finalBlob);
      };

      // Rewind both to start
      videoEl.currentTime = 0;
      audioEl.currentTime = 0;

      recorder.start(100);

      await Promise.all([videoEl.play(), audioEl.play()]);

      const duration = Math.max(videoEl.duration || 1, audioEl.duration || 1);

      let animId: number;
      const drawFrame = () => {
        if (videoEl.ended || videoEl.currentTime >= duration) {
          cancelAnimationFrame(animId);
          if (recorder.state === 'recording') {
            recorder.stop();
          }
          return;
        }

        ctx.drawImage(videoEl, 0, 0, width, height);

        const pct = Math.min(100, Math.round((videoEl.currentTime / duration) * 100));
        onProgress?.(pct);

        animId = requestAnimationFrame(drawFrame);
      };

      animId = requestAnimationFrame(drawFrame);

      videoEl.onended = () => {
        cancelAnimationFrame(animId);
        if (recorder.state === 'recording') {
          recorder.stop();
        }
      };
    } catch (err) {
      reject(err);
    }
  });
}
