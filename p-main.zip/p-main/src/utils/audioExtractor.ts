/**
 * Extracts and compresses audio track from a video file in the browser.
 * This dramatically speeds up upload time and prevents payload size errors.
 */

export async function extractAudioFromVideo(
  file: File,
  onProgress?: (msg: string) => void
): Promise<{ blob: Blob; base64: string; mimeType: string }> {
  // If file is already a lightweight audio file (< 20MB) or small video (< 15MB), send directly
  if (file.size <= 15 * 1024 * 1024 && (file.type.startsWith('audio/') || file.type.startsWith('video/'))) {
    onProgress?.('ဖိုင်ကို တိုက်ရိုက် ပြင်ဆင်နေသည်...');
    const buffer = await file.arrayBuffer();
    const base64 = arrayBufferToBase64(buffer);
    return {
      blob: file,
      base64,
      mimeType: file.type || 'video/mp4',
    };
  }

  onProgress?.('ဗီဒီယိုမှ အသံလှိုင်းကို ခွဲထုတ်နေပါသည် (Extracting audio)...');

  try {
    const arrayBuffer = await file.arrayBuffer();
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate: 16000, // 16kHz is ideal for speech transcription
    });

    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    onProgress?.('အသံဖိုင်ကို ချုံ့ယူနေပါသည် (Optimizing audio for Gemini AI)...');

    // Convert audio buffer to mono WAV
    const wavBlob = audioBufferToWav(audioBuffer);
    const wavArrayBuffer = await wavBlob.arrayBuffer();
    const base64 = arrayBufferToBase64(wavArrayBuffer);

    await audioContext.close();

    return {
      blob: wavBlob,
      base64,
      mimeType: 'audio/wav',
    };
  } catch (err) {
    console.warn('Browser audio extraction failed or format unsupported, falling back to direct video upload:', err);
    onProgress?.('ဗီဒီယိုဖိုင်ကို တိုက်ရိုက် ပေးပို့ရန် ပြင်ဆင်နေပါသည်...');
    const buffer = await file.arrayBuffer();
    return {
      blob: file,
      base64: arrayBufferToBase64(buffer),
      mimeType: file.type || 'video/mp4',
    };
  }
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  const chunkSize = 0x8000; // 32KB chunks to prevent stack overflow

  for (let i = 0; i < len; i += chunkSize) {
    const sub = bytes.subarray(i, Math.min(i + chunkSize, len));
    binary += String.fromCharCode.apply(null, sub as unknown as number[]);
  }

  return btoa(binary);
}

// Convert AudioBuffer to WAV format (16-bit PCM Mono)
function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numOfChan = 1; // Downmix to mono
  const length = buffer.length * numOfChan * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));
  const channels: Float32Array[] = [];
  let sample = 0;
  let offset = 0;
  let pos = 0;

  // Write WAV container header
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"

  setUint32(0x20746d66); // "fmt " chunk
  setUint32(16); // length = 16
  setUint16(1); // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(buffer.sampleRate);
  setUint32(buffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
  setUint16(numOfChan * 2); // block-align
  setUint16(16); // 16-bit precision

  setUint32(0x61746164); // "data" - chunk
  setUint32(length - pos - 4); // chunk length

  // Mix down channels to mono
  for (let i = 0; i < buffer.numberOfChannels; i++) {
    channels.push(buffer.getChannelData(i));
  }

  while (offset < buffer.length) {
    let monoSample = 0;
    for (let i = 0; i < channels.length; i++) {
      monoSample += channels[i][offset];
    }
    monoSample = monoSample / channels.length;

    sample = Math.max(-1, Math.min(1, monoSample));
    sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
    out.setInt16(pos, sample, true);
    pos += 2;
    offset++;
  }

  return new Blob([out.buffer], { type: 'audio/wav' });

  function setUint16(data: number) {
    out.setUint16(pos, data, true);
    pos += 2;
  }

  function setUint32(data: number) {
    out.setUint32(pos, data, true);
    pos += 4;
  }
}
