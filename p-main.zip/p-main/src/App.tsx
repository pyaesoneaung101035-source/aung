import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { StepNavigation } from './components/StepNavigation';
import { Step1ApiKey } from './components/Step1ApiKey';
import { Step2Upload } from './components/Step2Upload';
import { Step3Transcribe } from './components/Step3Transcribe';
import { Step4Transcript } from './components/Step4Transcript';
import { Step5VoiceClone } from './components/Step5VoiceClone';
import { Step6Dubbing } from './components/Step6Dubbing';
import { HistoryModal } from './components/HistoryModal';
import { AppLanguage, TranscribeOptions, TranscriptionResult, VoiceCloneAudioResult } from './types';
import { extractAudioFromVideo } from './utils/audioExtractor';
import { safeFetchJson } from './utils/audioSyncHelper';

const LOCAL_STORAGE_HISTORY_KEY = 'gemini_transcription_history';

export default function App() {
  const [appLang, setAppLang] = useState<AppLanguage>('my');
  const [apiKey, setApiKey] = useState<string>('');
  const [apiKeyConnected, setApiKeyConnected] = useState<boolean>(false);
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [hasEnvKey, setHasEnvKey] = useState<boolean>(false);
  const [connectionInfo, setConnectionInfo] = useState<{ latencyMs?: number; model?: string } | null>(null);

  const [currentStep, setCurrentStep] = useState<number>(1);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number>(0);

  const [options, setOptions] = useState<TranscribeOptions>({
    language: 'auto',
    translateToBurmese: true,
    includeTimestamps: true,
    exactTimestamps: true,
    diarization: true,
    generateSummary: true,
  });

  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [transcribeProgressMessage, setTranscribeProgressMessage] = useState<string>('');
  const [transcriptionError, setTranscriptionError] = useState<string | null>(null);
  const [transcriptionResult, setTranscriptionResult] = useState<TranscriptionResult | null>(null);
  const [extractedAudioBase64, setExtractedAudioBase64] = useState<string>('');
  const [extractedAudioName, setExtractedAudioName] = useState<string>('');
  const [voiceAudioResult, setVoiceAudioResult] = useState<VoiceCloneAudioResult | null>(null);

  const [history, setHistory] = useState<TranscriptionResult[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Load config status, auto-connect & history on mount
  useEffect(() => {
    // Check saved key first
    const savedKey = localStorage.getItem('user_gemini_api_key');
    if (savedKey) {
      setApiKey(savedKey);
    }

    // Fast check if server has GEMINI_API_KEY injected & auto-connect
    fetch('/api/config-status')
      .then((res) => res.json())
      .then((data) => {
        if (data.hasEnvKey) {
          setHasEnvKey(true);
        }
        if (data.autoConnected) {
          setApiKeyConnected(true);
          setConnectionInfo({
            latencyMs: data.latencyMs || 150,
            model: data.model || 'gemini-3.8-flash',
          });
        } else if (savedKey) {
          // Fast check user's saved key
          handleValidateKey(savedKey);
        }
      })
      .catch((err) => console.log('Config status check error:', err));

    // Load history
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_HISTORY_KEY);
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.warn('Failed to load history from localStorage', e);
    }
  }, []);

  // Step 1: Validate API Key - Fast Check (<200ms)
  const handleValidateKey = async (customKey?: string): Promise<boolean> => {
    setIsValidating(true);
    setTranscriptionError(null);
    try {
      const keyToSend = customKey !== undefined ? customKey : apiKey;
      const res = await fetch('/api/validate-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiKey: keyToSend }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setApiKeyConnected(true);
        setConnectionInfo({ latencyMs: data.latencyMs, model: data.model });
        if (keyToSend && keyToSend.trim()) {
          try {
            localStorage.setItem('user_gemini_api_key', keyToSend.trim());
          } catch {
            // ignore storage errors
          }
        }
        return true;
      }
      return false;
    } catch (err) {
      console.error('Validation error:', err);
      return false;
    } finally {
      setIsValidating(false);
    }
  };

  // Step 3 -> 4: Start AI Transcription
  const handleStartTranscribe = async () => {
    if (!selectedFile) return;

    setIsTranscribing(true);
    setTranscriptionError(null);
    setTranscribeProgressMessage(
      appLang === 'my' ? 'ဗီဒီယို ဖိုင်ကို စစ်ဆေးနေပါသည်...' : 'Analyzing media track...'
    );

    try {
      // 1. Process / extract audio from video for high-speed upload and zero payload issues
      const { base64, mimeType } = await extractAudioFromVideo(
        selectedFile,
        (msg) => setTranscribeProgressMessage(msg)
      );

      setExtractedAudioBase64(base64);
      setExtractedAudioName(selectedFile.name);

      setTranscribeProgressMessage(
        appLang === 'my'
          ? 'Gemini 3.8 Flash သို့ ပေးပို့ပြီး စာသားထုတ်ယူနေပါသည်...'
          : 'Sending to Gemini 3.8 Flash for speech-to-text processing...'
      );

      // 2. Call backend transcription API
      const response = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base64Data: base64,
          mimeType: mimeType,
          fileName: selectedFile.name,
          apiKey: apiKey,
          language: options.language,
          translateToBurmese: options.translateToBurmese,
          includeTimestamps: options.includeTimestamps,
          exactTimestamps: options.exactTimestamps,
          diarization: options.diarization,
          generateSummary: options.generateSummary,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Transcription failed on server');
      }

      const resultItem: TranscriptionResult = {
        id: 'tx_' + Date.now(),
        timestamp: Date.now(),
        fileName: selectedFile.name,
        fileSizeFormatted: (selectedFile.size / (1024 * 1024)).toFixed(2) + ' MB',
        durationFormatted: `${Math.floor(videoDuration / 60)}:${Math.floor(videoDuration % 60).toString().padStart(2, '0')}`,
        detectedLanguage: data.detectedLanguage || 'Auto',
        plainText: data.plainText,
        burmeseTranscript: data.burmeseTranscript || data.plainText,
        originalTranscript: data.originalTranscript || data.plainText,
        bilingualTranscript: data.bilingualTranscript || data.plainText,
        formattedTranscript: data.formattedTranscript || data.plainText,
        segments: data.segments || [],
        summary: data.summary || '',
        keyPoints: data.keyPoints || [],
        srtContent: data.srtContent || '',
        originalSrtContent: data.originalSrtContent || '',
      };

      setTranscriptionResult(resultItem);

      // Save to history
      const updatedHistory = [resultItem, ...history.filter((h) => h.id !== resultItem.id)].slice(0, 20);
      setHistory(updatedHistory);
      try {
        localStorage.setItem(LOCAL_STORAGE_HISTORY_KEY, JSON.stringify(updatedHistory));
      } catch (err) {
        console.warn('LocalStorage save error:', err);
      }

      // Navigate to Step 4
      setCurrentStep(4);
    } catch (err: any) {
      console.error('Transcription error:', err);
      setTranscriptionError(err.message || 'စာသားထုတ်ယူရာတွင် အမှားဖြစ်ပေါ်ပါသည်');
    } finally {
      setIsTranscribing(false);
      setTranscribeProgressMessage('');
    }
  };

  // Seek video player to specific timestamp from interactive transcript
  const handleSeekVideo = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = seconds;
      videoRef.current.play().catch(() => {});
      // Smooth scroll back to video if needed
      window.scrollTo({ top: 150, behavior: 'smooth' });
    }
  };

  const handleStartNew = () => {
    setSelectedFile(null);
    if (videoPreviewUrl) {
      URL.revokeObjectURL(videoPreviewUrl);
    }
    setVideoPreviewUrl(null);
    setVideoDuration(0);
    setTranscriptionResult(null);
    setCurrentStep(2);
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem(LOCAL_STORAGE_HISTORY_KEY);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-500/30">
      {/* Top Header */}
      <Header
        apiKeyConnected={apiKeyConnected}
        appLang={appLang}
        setAppLang={setAppLang}
        onOpenHistory={() => setIsHistoryOpen(true)}
        historyCount={history.length}
      />

      {/* 6-Step Stepper Navigation */}
      <StepNavigation
        currentStep={currentStep}
        onSelectStep={(step) => setCurrentStep(step)}
        apiKeyConnected={apiKeyConnected}
        hasVideo={Boolean(selectedFile)}
        hasTranscript={Boolean(transcriptionResult)}
        hasVoiceAudio={Boolean(voiceAudioResult)}
        appLang={appLang}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* If video is selected and we are on Step 3, 4, or 5, keep a compact video player view at top for scrubbing */}
        {selectedFile && currentStep >= 3 && currentStep < 6 && videoPreviewUrl && (
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center gap-4">
            <div className="w-full md:w-64 h-36 bg-black rounded-xl overflow-hidden shrink-0 border border-slate-800">
              <video
                ref={videoRef}
                src={videoPreviewUrl}
                controls
                className="w-full h-full object-contain"
              />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider">
                {appLang === 'my' ? 'လက်ရှိ ရွေးချယ်ထားသော ဗီဒီယို' : 'Active Video'}
              </span>
              <h3 className="text-sm font-semibold text-white truncate mt-0.5">
                {selectedFile.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {appLang === 'my'
                  ? 'အောက်ဖော်ပြပါ Transcript ရှိ အချိန်မှတ်သားချက် [00:15] များကို နှိပ်ပါက ဗီဒီယိုကို ထိုအချိန်သို့ တိုက်ရိုက် ရွှေ့ပေးပါမည်'
                  : 'Clicking any timestamp [00:15] below will automatically jump this video to that exact point'}
              </p>
            </div>
            <button
              onClick={() => setCurrentStep(2)}
              className="px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition shrink-0"
            >
              {appLang === 'my' ? 'ဗီဒီယို ပြောင်းလဲမည်' : 'Change Video'}
            </button>
          </div>
        )}

        {/* Dynamic Step View based on currentStep */}
        {currentStep === 1 && (
          <Step1ApiKey
            apiKey={apiKey}
            setApiKey={setApiKey}
            apiKeyConnected={apiKeyConnected}
            onValidateKey={handleValidateKey}
            isValidating={isValidating}
            hasEnvKey={hasEnvKey}
            onProceedToStep2={() => setCurrentStep(2)}
            appLang={appLang}
            connectionInfo={connectionInfo}
          />
        )}

        {currentStep === 2 && (
          <Step2Upload
            selectedFile={selectedFile}
            setSelectedFile={setSelectedFile}
            videoPreviewUrl={videoPreviewUrl}
            setVideoPreviewUrl={setVideoPreviewUrl}
            videoRef={videoRef}
            onProceedToStep3={() => setCurrentStep(3)}
            appLang={appLang}
            videoDuration={videoDuration}
            setVideoDuration={setVideoDuration}
          />
        )}

        {currentStep === 3 && (
          <Step3Transcribe
            options={options}
            setOptions={setOptions}
            isTranscribing={isTranscribing}
            transcribeProgressMessage={transcribeProgressMessage}
            onStartTranscribe={handleStartTranscribe}
            appLang={appLang}
            errorMsg={transcriptionError}
            videoFileName={selectedFile?.name || 'video'}
          />
        )}

        {currentStep === 4 && transcriptionResult && (
          <Step4Transcript
            result={transcriptionResult}
            onSeekVideo={handleSeekVideo}
            onStartNew={handleStartNew}
            onProceedToStep5={() => setCurrentStep(5)}
            appLang={appLang}
          />
        )}

        {currentStep === 5 && transcriptionResult && (
          <Step5VoiceClone
            transcriptionResult={transcriptionResult}
            referenceAudioBase64={extractedAudioBase64}
            referenceAudioName={extractedAudioName}
            appLang={appLang}
            apiKey={apiKey}
            onProceedToStep6={() => setCurrentStep(6)}
            voiceAudioResult={voiceAudioResult}
            setVoiceAudioResult={setVoiceAudioResult}
          />
        )}

        {currentStep === 6 && transcriptionResult && (
          <Step6Dubbing
            videoPreviewUrl={videoPreviewUrl}
            videoFileName={selectedFile?.name || 'video.mp4'}
            voiceAudioResult={voiceAudioResult}
            setVoiceAudioResult={setVoiceAudioResult}
            transcriptionResult={transcriptionResult}
            referenceAudioBase64={extractedAudioBase64}
            referenceAudioName={extractedAudioName}
            apiKey={apiKey}
            appLang={appLang}
            onStartNew={handleStartNew}
            onGoToStep5={() => setCurrentStep(5)}
            onSelectNewVideo={(file) => {
              setSelectedFile(file);
              const url = URL.createObjectURL(file);
              setVideoPreviewUrl(url);
            }}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            Gemini Video Transcriber, Burmese Voice Clone & Dubbing • {appLang === 'my' ? 'အဆင့် ၆ ဆင့်ဖြင့် ဗီဒီယို စာသား၊ အသံနှင့် Dubbing ပေါင်းစပ်စနစ်' : '6-step video transcription, voice cloning & dubbing studio'}
          </p>
          <div className="flex items-center gap-4">
            <span>Powered by Gemini 3.8 Flash & VoxCPM (tharlaimar/voxcpm)</span>
          </div>
        </div>
      </footer>

      {/* History Drawer Modal */}
      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelect={(item) => {
          setTranscriptionResult(item);
          setCurrentStep(4);
        }}
        onClearHistory={handleClearHistory}
        appLang={appLang}
      />
    </div>
  );
}
